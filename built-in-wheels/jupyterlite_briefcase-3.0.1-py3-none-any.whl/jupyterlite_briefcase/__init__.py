"""Export the hosted launcher and register the prebuilt import extension."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from importlib.resources import files
from pathlib import Path
from urllib.parse import urlsplit


def _jupyter_labextension_paths():
    return [
        {"src": "labextension", "dest": "@jupyterlite/briefcase"},
        {"src": "export-labextension", "dest": "@jupyterlite/briefcase-export"},
    ]


def export_launcher(output: Path, app_url: str) -> Path:
    parsed = urlsplit(app_url)
    if (
        not app_url
        or "\\" in app_url
        or any(ord(char) < 32 for char in app_url)
        or parsed.query
        or parsed.fragment
        or parsed.username
        or parsed.password
        or (not parsed.scheme and parsed.netloc)
        or (
            parsed.scheme
            and not (
                parsed.scheme == "https"
                or (
                    parsed.scheme == "http"
                    and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
                )
            )
        )
        or (parsed.scheme and not parsed.netloc)
    ):
        raise ValueError("app_url must be a relative URL or HTTPS/loopback HTTP URL without credentials, query, or fragment")
    assets = files(__package__).joinpath("launcher")
    bundle = assets.joinpath("launcher.js")
    if not bundle.is_file():
        raise FileNotFoundError("Launcher bundle missing. Run npm run build first.")
    output.mkdir(parents=True, exist_ok=True)
    html = output / "index.html"
    javascript = output / "launcher.js"
    if html.exists() or javascript.exists():
        raise FileExistsError("Refusing to overwrite an existing launcher; choose an empty output directory.")
    config = json.dumps({"appUrl": app_url}, ensure_ascii=True).replace("</", "<\\/")
    with html.open("x", encoding="utf-8") as destination:
        destination.write(assets.joinpath("index.html").read_text().replace("__BRIEFCASE_CONFIG__", config))
    with bundle.open("rb") as source, javascript.open("xb") as destination:
        shutil.copyfileobj(source, destination)
    return html


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export an HTTP(S)-hosted notebook import launcher.")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--app-url", default="../lab/", help="Hosted app URL (default: ../lab/)")
    args = parser.parse_args(argv)
    try:
        output = export_launcher(args.output_dir, args.app_url)
    except (OSError, ValueError) as error:
        print(f"Could not export launcher: {error}", file=sys.stderr)
        return 1
    print(f"Wrote {output}. Serve this directory over HTTP(S); file:// is unsupported.")
    return 0
