"""Generate a local HTML file that hands notebooks to a hosted JupyterLite site.

The file can be opened directly from disk (``file://``). It navigates to the
hosted app with the files compressed into the URL fragment; the Briefcase
receiver on that site asks for confirmation and saves a copy in the site's
browser storage, where the kernel and file browser can use it.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import re
import struct
import sys
import zlib
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

LINK_KEY = "briefcase-import"
LINK_VERSION = "1"
# Version 2 carries one part of a link too long for a single URL:
# `2.<sha256 of the whole payload>.<index>.<count>.<payload chunk>`.
PARTS_VERSION = "2"
MAX_DEPTH = 16
# Chromium rejects navigations to URLs longer than 2 MiB; Firefox's default is 1 MiB.
CHROMIUM_URL_LIMIT = 2 * 1024 * 1024
FIREFOX_URL_LIMIT = 1024 * 1024
# Payload characters per part URL. Staying under Firefox's limit lets every part open anywhere.
PART_CHARS = 1_000_000
# The receiver accepts at most this many parts.
MAX_PARTS = 16
LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}


def _valid_part(part: str) -> bool:
    return (
        0 < len(part) <= 255
        and part not in {".", ".."}
        and not any(ord(char) < 32 or ord(char) == 127 or char in "\\/:" for char in part)
    )


def validate_app_url(app_url: str) -> str:
    parsed = urlsplit(app_url)
    secure = parsed.scheme == "https" or (parsed.scheme == "http" and parsed.hostname in LOOPBACK_HOSTS)
    if not secure or not parsed.netloc or parsed.username or parsed.password or parsed.fragment or "\\" in app_url:
        raise ValueError("--app-url must be an absolute HTTPS (or loopback HTTP) URL without credentials or fragment")
    return app_url


def collect_sources(paths: list[Path]) -> dict[str, Path]:
    """Map each embedded name to its file on disk.

    Reads one directory recursively, or a list of individual files.
    """
    sources: dict[str, Path] = {}
    if len(paths) == 1 and paths[0].is_dir():
        root = paths[0]
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if any(part.startswith(".") for part in relative.parts) or not path.is_file():
                continue
            sources[relative.as_posix()] = path
    else:
        for path in paths:
            if not path.is_file():
                raise ValueError(f"{path} is not a file (pass a single directory to include a folder)")
            if path.name in sources:
                raise ValueError(f"duplicate file name {path.name}")
            sources[path.name] = path
    if not sources:
        raise ValueError("no files to include")
    seen: set[str] = set()
    for name in sources:
        parts = name.split("/")
        if len(parts) > MAX_DEPTH or len(name) > 1024 or not all(map(_valid_part, parts)):
            raise ValueError(f"unsupported path {name!r}")
        if name.lower() in seen:
            raise ValueError(f"paths differ only by case: {name!r}")
        seen.add(name.lower())
    return sources


def collect_files(paths: list[Path]) -> dict[str, bytes]:
    """Read the files found by collect_sources."""
    return {name: path.read_bytes() for name, path in collect_sources(paths).items()}


def default_output_name(sources: dict[str, Path], app_url: str) -> str:
    """Name the default output after the embedded files.

    One file: its name. One notebook: its name. Several notebooks: the first two
    stems. Two other files: both names. Files in one folder: the folder name.
    Anything else: the app URL's host name.
    """
    names = [PurePosixPath(name).name for name in sources]
    notebooks = [name for name in names if name.lower().endswith(".ipynb")]
    if len(names) == 1:
        return f"{names[0]}.html"
    if len(notebooks) == 1:
        return f"{notebooks[0]}.html"
    if len(notebooks) > 1:
        return f"{Path(notebooks[0]).stem}-{Path(notebooks[1]).stem}.ipynb.html"
    if len(names) == 2:
        return f"{names[0]}-{names[1]}.html"
    folders = {path.resolve().parent for path in sources.values()}
    if len(folders) == 1:
        folder = folders.pop().name
        if folder:
            return f"{folder}.html"
    host = re.sub(r"[^A-Za-z0-9.-]", "-", urlsplit(app_url).hostname or "")
    return f"{host.strip('.-') or 'jupyterlite'}.html"


def check_notebook(name: str, data: bytes) -> None:
    try:
        notebook = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise ValueError(f"{name} is not valid notebook JSON: {error}") from None
    if not isinstance(notebook, dict) or (notebook.get("nbformat"), notebook.get("nbformat_minor")) != (4, 5):
        raise ValueError(
            f"{name} is not nbformat 4.5; the receiver only accepts 4.5. "
            "Convert it first, for example with: jupyter nbconvert --to notebook --inplace " + name
        )
    cells = notebook.get("cells")
    if not isinstance(cells, list) or not all(isinstance(cell, dict) and isinstance(cell.get("id"), str) for cell in cells):
        raise ValueError(f"{name} has cells without ids, which nbformat 4.5 requires")


def encode_payload(files: dict[str, bytes], notebook_path: str, directory_name: str = "") -> str:
    """base64url(deflate-raw(u32 header length + JSON header + file bytes))."""
    fields = {
        "notebookPath": notebook_path,
        "entries": [{"path": path, "byteLength": len(data)} for path, data in files.items()],
    }
    if directory_name:
        fields["directoryName"] = directory_name
    header = json.dumps(fields, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
    raw = struct.pack(">I", len(header)) + header + b"".join(files.values())
    compressed = compressor.compress(raw) + compressor.flush()
    return base64.urlsafe_b64encode(compressed).rstrip(b"=").decode("ascii")


def build_link(app_url: str, files: dict[str, bytes], notebook_path: str, directory_name: str = "") -> str:
    return f"{app_url}#{LINK_KEY}={LINK_VERSION}.{encode_bundle(app_url, files, notebook_path, directory_name)}"


def split_payload(encoded: str) -> list[str]:
    count = -(-len(encoded) // PART_CHARS)
    if count > MAX_PARTS:
        raise ValueError(
            f"the bundle is {len(encoded):,} encoded characters; links carry at most "
            f"{MAX_PARTS * PART_CHARS:,}. Share fewer or smaller files."
        )
    return [encoded[start : start + PART_CHARS] for start in range(0, len(encoded), PART_CHARS)]


def build_links(app_url: str, files: dict[str, bytes], notebook_path: str, directory_name: str = "") -> list[str]:
    """Return one link, or several part links when the single link would exceed the Chromium limit."""
    encoded = encode_bundle(app_url, files, notebook_path, directory_name)
    link = f"{app_url}#{LINK_KEY}={LINK_VERSION}.{encoded}"
    if len(link) < CHROMIUM_URL_LIMIT:
        return [link]
    chunks = split_payload(encoded)
    digest = hashlib.sha256(encoded.encode("ascii")).hexdigest()
    return [
        f"{app_url}#{LINK_KEY}={PARTS_VERSION}.{digest}.{index}.{len(chunks)}.{chunk}"
        for index, chunk in enumerate(chunks)
    ]


def encode_bundle(app_url: str, files: dict[str, bytes], notebook_path: str, directory_name: str = "") -> str:
    validate_app_url(app_url)
    if directory_name and not _valid_part(directory_name):
        raise ValueError(f"file name {directory_name!r} cannot name a folder")
    if notebook_path:
        if notebook_path not in files or not notebook_path.lower().endswith(".ipynb"):
            raise ValueError(f"notebook to open {notebook_path!r} is not one of the included .ipynb files")
    elif any(name.lower().endswith(".ipynb") for name in files):
        raise ValueError("a bundle with .ipynb files must name the notebook to open")
    for name, data in files.items():
        if name.lower().endswith(".ipynb"):
            check_notebook(name, data)
    return encode_payload(files, notebook_path, directory_name)


def render_html(urls: str | list[str], files: dict[str, bytes], notebook_path: str, redirect: bool = True) -> str:
    links = [urls] if isinstance(urls, str) else list(urls)
    split = len(links) > 1
    # A split link opens several tabs, which browsers allow only from a click, so the page never navigates by itself.
    redirect = redirect and not split
    target = urlsplit(links[0])
    site = f"{target.scheme}://{target.netloc}"
    total = sum(map(len, files.values()))
    items = "\n".join(
        f"<li>{html.escape(name)} <small>({len(data):,} bytes)</small></li>" for name, data in files.items()
    )
    config = json.dumps({"urls": links, "redirect": redirect}).replace("<", "\\u003c")
    action = f"Open {html.escape(notebook_path)}" if notebook_path else "Import files"
    opening = (
        "Your browser may ask to allow pop-ups. The import opens "
        f"{len(links)} tabs; the extra tabs close themselves, and one tab shows the result."
        if split
        else ("Opening&hellip;" if redirect else "")
    )
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>{action} in {html.escape(target.netloc)}</title>
<style>
body {{ font: 15px/1.5 system-ui, sans-serif; margin: 2rem auto; max-width: 42rem; padding: 0 1rem; color: #222; }}
a.button {{ display: inline-block; padding: .5rem 1rem; background: #1565c0; color: #fff; border-radius: 4px; text-decoration: none; }}
small {{ color: #666; }}
</style>
</head>
<body>
<main>
<h1>{action}</h1>
<p>This file opens <strong>{html.escape(site)}</strong> and offers it {len(files)} file(s), {total:,} bytes in total.
The site asks for confirmation, then saves a copy in its browser storage. The files travel in the
address fragment, which is not sent to the server.</p>
<ul>
{items}
</ul>
<p><a id="open" class="button" href="#">Open in {html.escape(target.netloc)}</a></p>
<p id="status"><small>{opening}</small></p>
</main>
<script id="briefcase-link" type="application/json">{config}</script>
<script>
const config = JSON.parse(document.getElementById('briefcase-link').textContent);
const open = document.getElementById('open');
const status = document.getElementById('status');
if (config.urls.length === 1) {{
  open.href = config.urls[0];
  if (config.redirect) {{
    location.replace(config.urls[0]);
  }}
}} else {{
  open.addEventListener('click', event => {{
    event.preventDefault();
    const opened = [];
    for (const url of config.urls) {{
      const tab = window.open(url, '_blank');
      if (tab === null) {{
        opened.forEach(earlier => earlier.close());
        status.textContent = 'Your browser blocked a tab. Allow pop-ups for this file, then click again. Nothing was imported.';
        return;
      }}
      tab.opener = null;
      opened.push(tab);
    }}
    status.textContent = 'Opened ' + opened.length + ' tabs. The import finishes in one of them.';
  }});
}}
</script>
</body>
</html>
"""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("paths", nargs="+", type=Path, help="Notebook/companion files, or one directory to include recursively (hidden entries are skipped)")
    parser.add_argument("--app-url", required=True, help="Hosted app page, for example https://datax.now/lab/index.html")
    parser.add_argument("--open", dest="notebook", help="Notebook to open, relative to the included files (default: first .ipynb)")
    parser.add_argument("--output", type=Path, help="HTML file to write (default: named after the embedded files in the current directory, see docs)")
    parser.add_argument("--no-redirect", action="store_true", help="Show a button instead of navigating automatically")
    args = parser.parse_args(argv)
    try:
        sources = collect_sources(args.paths)
        files = {name: path.read_bytes() for name, path in sources.items()}
        notebooks = [name for name in files if name.lower().endswith(".ipynb")]
        notebook = args.notebook or (notebooks[0] if notebooks else "")
        output = args.output or Path(default_output_name(sources, args.app_url))
        urls = build_links(args.app_url, files, notebook, output.name)
        output.write_text(render_html(urls, files, notebook, not args.no_redirect), encoding="utf-8")
    except (OSError, ValueError) as error:
        print(f"Could not create link: {error}", file=sys.stderr)
        return 1
    size = sum(map(len, urls))
    if len(urls) > 1:
        print(
            f"Wrote {output} ({len(files)} file(s) in {len(urls)} linked parts, {size:,} characters, "
            f"opens {notebook or 'no notebook'}). Open it and click the button; the parts merge automatically."
        )
    else:
        print(f"Wrote {output} ({len(files)} file(s), link {size:,} characters, opens {notebook or 'no notebook'}).")
    if any(len(url) >= FIREFOX_URL_LIMIT for url in urls):
        print("Warning: links over 1 MiB do not open in Firefox's default configuration.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
