"""jupyterlite-xeus-x — kernel bundle for JupyterLite."""
__version__ = '20261005.1471.0'
