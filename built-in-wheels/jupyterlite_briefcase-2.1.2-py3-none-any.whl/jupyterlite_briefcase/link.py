"""Generate a local HTML file that hands notebooks to a hosted JupyterLite site.

The file can be opened directly from disk (``file://``). It navigates to the
hosted app with the files compressed into the URL fragment; the Briefcase
receiver on that site asks for confirmation and saves a copy in the site's
browser storage, where the kernel and file browser can use it.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import re
import struct
import sys
import uuid
import zlib
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

LINK_KEY = "briefcase-import"
LINK_VERSION = "1"
# Version 2 carries one part of a link too long for a single URL:
# `2.<sha256 of the whole payload>.<index>.<count>.<payload chunk>`.
PARTS_VERSION = "2"
MAX_DEPTH = 16
# Chromium rejects navigations to URLs longer than 2 MiB; Firefox's default is 1 MiB.
CHROMIUM_URL_LIMIT = 2 * 1024 * 1024
FIREFOX_URL_LIMIT = 1024 * 1024
# Payload characters per part URL. Staying under Firefox's limit lets every part open anywhere.
PART_CHARS = 1_000_000
# The receiver accepts at most this many parts.
MAX_PARTS = 16
LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}
MAX_URL_CHARS = 2048
# `[NAME=]http(s)://...` on the command line names a file the site downloads when the link is opened.
REMOTE_ARGUMENT = re.compile(r"(?:(?P<name>[^=]+)=)?(?P<url>https?://.+)", re.DOTALL)
CELL_ID = re.compile(r"[a-zA-Z0-9_-]{1,64}")
DEFAULT_APP_URLS = [
    "https://datax.now/lab/index.html",
    "https://datax-now.readthedocs.io/en/latest/_static/lab/index.html",
]


def _valid_part(part: str) -> bool:
    return (
        0 < len(part) <= 255
        and part not in {".", ".."}
        and not any(ord(char) < 32 or ord(char) == 127 or char in "\\/:" for char in part)
    )


def validate_app_url(app_url: str) -> str:
    parsed = urlsplit(app_url)
    secure = parsed.scheme == "https" or (parsed.scheme == "http" and parsed.hostname in LOOPBACK_HOSTS)
    if not secure or not parsed.netloc or parsed.username or parsed.password or parsed.fragment or "\\" in app_url:
        raise ValueError("--app-url must be an absolute HTTPS (or loopback HTTP) URL without credentials or fragment")
    return app_url


def validate_remote_url(url: str) -> str:
    """Accept what the receiver fetches: HTTPS (or loopback HTTP), no credentials, no fragment."""
    parsed = urlsplit(url)
    secure = parsed.scheme == "https" or (parsed.scheme == "http" and parsed.hostname in LOOPBACK_HOSTS)
    if (
        not secure
        or not parsed.netloc
        or parsed.username
        or parsed.password
        or parsed.fragment
        or len(url) > MAX_URL_CHARS
        or "\\" in url
        or any(ord(char) <= 32 or ord(char) == 127 for char in url)
    ):
        raise ValueError(
            f"{url!r} is not a supported external URL (use HTTPS, or loopback HTTP, without credentials, "
            "spaces or a #fragment)"
        )
    return url


def parse_remote_argument(argument: str) -> tuple[str, str] | None:
    """Split ``[NAME=]URL`` into (name, url), or return None when the argument is not a URL.

    Without NAME, the last segment of the URL path names the file.
    """
    match = REMOTE_ARGUMENT.fullmatch(argument)
    if match is None:
        return None
    url = validate_remote_url(match["url"])
    name = match["name"] or unquote(urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1])
    if not name:
        raise ValueError(f"cannot name a file after {url}; use NAME={url}")
    return name, url


def check_names(names: list[str]) -> None:
    seen: set[str] = set()
    for name in names:
        parts = name.split("/")
        if len(parts) > MAX_DEPTH or len(name) > 1024 or not all(map(_valid_part, parts)):
            raise ValueError(f"unsupported path {name!r}")
        if name.lower() in seen:
            raise ValueError(f"paths differ only by case: {name!r}")
        seen.add(name.lower())


def collect_remote(arguments: list[str]) -> dict[str, str]:
    """Map each embedded name to the external URL it is downloaded from at import time."""
    remote: dict[str, str] = {}
    for argument in arguments:
        parsed = parse_remote_argument(argument)
        if parsed is None:
            raise ValueError(f"{argument!r} is not an external URL")
        name, url = parsed
        if name in remote:
            raise ValueError(f"duplicate file name {name}")
        remote[name] = url
    check_names(list(remote))
    return remote


def collect_sources(paths: list[Path], remote_names: list[str] | None = None) -> dict[str, Path]:
    """Map each embedded name to its file on disk.

    Reads one directory recursively, or a list of individual files. Names of
    external URLs are only checked against the local ones; they are not read.
    """
    sources: dict[str, Path] = {}
    if len(paths) == 1 and paths[0].is_dir():
        root = paths[0]
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if any(part.startswith(".") for part in relative.parts) or not path.is_file():
                continue
            sources[relative.as_posix()] = path
    else:
        for path in paths:
            if not path.is_file():
                raise ValueError(f"{path} is not a file (pass a single directory to include a folder)")
            if path.name in sources:
                raise ValueError(f"duplicate file name {path.name}")
            sources[path.name] = path
    if not sources and not remote_names:
        raise ValueError("no files to include")
    check_names([*sources, *(remote_names or [])])
    return sources


def collect_files(paths: list[Path]) -> dict[str, bytes]:
    """Read the files found by collect_sources."""
    return {name: path.read_bytes() for name, path in collect_sources(paths).items()}


def default_output_name(sources: dict[str, Path], app_url: str, remote_names: list[str] | None = None) -> str:
    """Name the default output after the embedded files.

    One file: its name. One notebook: its name. Several notebooks: the first two
    stems. Two other files: both names. Files in one folder: the folder name.
    Anything else: the app URL's host name. External files count like embedded
    ones, except that they say nothing about a folder.
    """
    names = [PurePosixPath(name).name for name in [*sources, *(remote_names or [])]]
    notebooks = [name for name in names if name.lower().endswith(".ipynb")]
    if len(names) == 1:
        return f"{names[0]}.html"
    if len(notebooks) == 1:
        return f"{notebooks[0]}.html"
    if len(notebooks) > 1:
        return f"{Path(notebooks[0]).stem}-{Path(notebooks[1]).stem}.ipynb.html"
    if len(names) == 2:
        return f"{names[0]}-{names[1]}.html"
    folders = {path.resolve().parent for path in sources.values()}
    if len(folders) == 1 and not remote_names:
        folder = folders.pop().name
        if folder:
            return f"{folder}.html"
    host = re.sub(r"[^A-Za-z0-9.-]", "-", urlsplit(app_url).hostname or "")
    return f"{host.strip('.-') or 'jupyterlite'}.html"


def _load_notebook(name: str, data: bytes) -> dict:
    try:
        notebook = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise ValueError(f"{name} is not valid notebook JSON: {error}") from None
    if not isinstance(notebook, dict):
        raise ValueError(f"{name} is not a notebook object")
    return notebook


def _new_cell_id(used: set[str]) -> str:
    while True:
        candidate = uuid.uuid4().hex[:8]
        if candidate not in used:
            used.add(candidate)
            return candidate


def _add_cell_ids(name: str, notebook: dict) -> None:
    """Give every cell a new id, as nbformat does when it upgrades 4.x notebooks to 4.5."""
    cells = notebook.get("cells")
    if not isinstance(cells, list) or not all(isinstance(cell, dict) for cell in cells):
        raise ValueError(f"{name} has no valid cells list")
    used: set[str] = set()
    for cell in cells:
        cell["id"] = _new_cell_id(used)


def _convert_with_nbformat(name: str, data: bytes, version: int) -> dict:
    """Convert an nbformat 1 to 3 notebook. The nbformat package is optional and only needed here."""
    try:
        import nbformat
    except ImportError:
        raise ValueError(
            f"{name} is nbformat {version}; converting it needs the nbformat package. "
            "Install it with: pip install 'jupyterlite-briefcase[convert]'"
        ) from None
    try:
        notebook = nbformat.reads(data.decode("utf-8"), as_version=4)
        nbformat.validate(notebook)
    except Exception as error:  # nbformat raises several exception types for notebooks it cannot convert.
        raise ValueError(f"{name} could not be converted to nbformat 4.5: {error}") from None
    return notebook


def upgrade_notebook(name: str, data: bytes) -> bytes:
    """Return the notebook as nbformat 4.5 JSON. A 4.5 notebook is returned unchanged.

    Notebooks from 4.0 to 4.4 differ from 4.5 only by cell ids, so they get new ids.
    Notebooks from nbformat 1 to 3 are converted by the nbformat package.
    """
    notebook = _load_notebook(name, data)
    version, minor = notebook.get("nbformat"), notebook.get("nbformat_minor")
    if (version, minor) == (4, 5):
        return data
    if version == 4 and isinstance(minor, int) and not isinstance(minor, bool) and 0 <= minor < 5:
        _add_cell_ids(name, notebook)
        notebook["nbformat_minor"] = 5
    elif version in (1, 2, 3):
        notebook = _convert_with_nbformat(name, data, version)
    else:
        raise ValueError(f"{name} is nbformat {version}.{minor}; only nbformat 1 to 4.5 can be included")
    return (json.dumps(notebook, indent=1, ensure_ascii=False) + "\n").encode("utf-8")


def upgrade_notebooks(files: dict[str, bytes]) -> dict[str, bytes]:
    return {
        name: upgrade_notebook(name, data) if name.lower().endswith(".ipynb") else data
        for name, data in files.items()
    }


def check_notebook(name: str, data: bytes) -> None:
    """Check what the receiver requires: nbformat 4.5 with a unique, valid id on every cell."""
    notebook = _load_notebook(name, data)
    if (notebook.get("nbformat"), notebook.get("nbformat_minor")) != (4, 5):
        raise ValueError(f"{name} is not nbformat 4.5")
    cells = notebook.get("cells")
    if not isinstance(cells, list) or not all(isinstance(cell, dict) for cell in cells):
        raise ValueError(f"{name} has no valid cells list")
    ids = [cell.get("id") for cell in cells]
    if not all(isinstance(cell_id, str) and CELL_ID.fullmatch(cell_id) for cell_id in ids) or len(set(ids)) != len(ids):
        raise ValueError(f"{name} needs a unique cell id (1 to 64 letters, digits, '-' or '_') in every cell")


def encode_payload(
    files: dict[str, bytes], notebook_path: str, directory_name: str = "", remote: dict[str, str] | None = None
) -> str:
    """base64url(deflate-raw(u32 header length + JSON header + file bytes)).

    External files are listed apart, in ``remote``, which receivers without remote support ignore, so that they
    still import the embedded files. For them ``notebookPath`` names an embedded notebook (or none), and
    ``openPath`` names the external notebook that newer receivers open instead.
    """
    remote = remote or {}
    embedded_notebook = notebook_path if notebook_path in files else ""
    if not embedded_notebook and notebook_path:
        embedded_notebook = next((name for name in files if name.lower().endswith(".ipynb")), "")
    fields: dict = {
        "notebookPath": embedded_notebook,
        "entries": [{"path": path, "byteLength": len(data)} for path, data in files.items()],
    }
    if remote:
        fields["remote"] = [{"path": path, "url": url} for path, url in remote.items()]
        if notebook_path != embedded_notebook:
            fields["openPath"] = notebook_path
    if directory_name:
        fields["directoryName"] = directory_name
    header = json.dumps(fields, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
    raw = struct.pack(">I", len(header)) + header + b"".join(files.values())
    compressed = compressor.compress(raw) + compressor.flush()
    return base64.urlsafe_b64encode(compressed).rstrip(b"=").decode("ascii")


def build_link(
    app_url: str,
    files: dict[str, bytes],
    notebook_path: str,
    directory_name: str = "",
    remote: dict[str, str] | None = None,
) -> str:
    encoded = encode_bundle(app_url, files, notebook_path, directory_name, remote)
    return f"{app_url}#{LINK_KEY}={LINK_VERSION}.{encoded}"


def split_payload(encoded: str) -> list[str]:
    count = -(-len(encoded) // PART_CHARS)
    if count > MAX_PARTS:
        raise ValueError(
            f"the bundle is {len(encoded):,} encoded characters; links carry at most "
            f"{MAX_PARTS * PART_CHARS:,}. Share fewer or smaller files."
        )
    return [encoded[start : start + PART_CHARS] for start in range(0, len(encoded), PART_CHARS)]


def build_links(
    app_url: str | list[str],
    files: dict[str, bytes],
    notebook_path: str,
    directory_name: str = "",
    remote: dict[str, str] | None = None,
) -> list[str]:
    """Return one link, or several part links when the single link would exceed the Chromium limit.

    The links point at the first site. The size check uses the longest site, so every listed site can open every part.
    """
    app_urls = [app_url] if isinstance(app_url, str) else list(app_url)
    for url in app_urls:
        validate_app_url(url)
    first = app_urls[0]
    encoded = encode_bundle(first, files, notebook_path, directory_name, remote)
    fragment = f"{LINK_KEY}={LINK_VERSION}.{encoded}"
    if max(len(url) for url in app_urls) + 1 + len(fragment) < CHROMIUM_URL_LIMIT:
        return [f"{first}#{fragment}"]
    chunks = split_payload(encoded)
    digest = hashlib.sha256(encoded.encode("ascii")).hexdigest()
    return [
        f"{first}#{LINK_KEY}={PARTS_VERSION}.{digest}.{index}.{len(chunks)}.{chunk}"
        for index, chunk in enumerate(chunks)
    ]


def encode_bundle(
    app_url: str,
    files: dict[str, bytes],
    notebook_path: str,
    directory_name: str = "",
    remote: dict[str, str] | None = None,
) -> str:
    validate_app_url(app_url)
    remote = remote or {}
    if not files and not remote:
        raise ValueError("no files to include")
    for url in remote.values():
        validate_remote_url(url)
    check_names([*files, *remote])
    files = upgrade_notebooks(files)
    names = [*files, *remote]
    if directory_name and not _valid_part(directory_name):
        raise ValueError(f"file name {directory_name!r} cannot name a folder")
    if notebook_path:
        if notebook_path not in names or not notebook_path.lower().endswith(".ipynb"):
            raise ValueError(f"notebook to open {notebook_path!r} is not one of the included .ipynb files")
    elif any(name.lower().endswith(".ipynb") for name in names):
        raise ValueError("a bundle with .ipynb files must name the notebook to open")
    for name, data in files.items():
        if name.lower().endswith(".ipynb"):
            check_notebook(name, data)
    return encode_payload(files, notebook_path, directory_name, remote)


def render_html(
    urls: str | list[str],
    files: dict[str, bytes],
    notebook_path: str,
    redirect: bool = True,
    hosts: list[str] | None = None,
    launcher_name: str | None = None,
    remote: dict[str, str] | None = None,
) -> str:
    # `urls` are the links for the first site; only the fragment changes for alternative hosts.
    links = [urls] if isinstance(urls, str) else list(urls)
    split = len(links) > 1
    # A split link opens several tabs, which browsers allow only from a click, so the page never navigates by itself.
    redirect = redirect and not split
    sites = list(dict.fromkeys(hosts)) if hosts else [links[0].split("#", 1)[0]]
    targets = [urlsplit(site) for site in sites]
    redirect = redirect and len(sites) == 1
    total = sum(map(len, files.values()))
    remote = remote or {}
    items = "\n".join(
        [f"<li>{html.escape(name)} <small>({len(data):,} bytes)</small></li>" for name, data in files.items()]
        + [
            f'<li>{html.escape(name)} <small><span data-i18n="remoteItem"></span> '
            f'<span class="remote-url">{html.escape(url)}</span></small></li>'
            for name, url in remote.items()
        ]
    )
    config = json.dumps(
        {
            "urls": links,
            "hosts": sites,
            "redirect": redirect,
            "fileCount": len(files),
            "remoteCount": len(remote),
            "totalBytes": total,
            "launcherName": launcher_name or (f"{notebook_path}.html" if notebook_path else "files.html"),
        }
    ).replace("<", "\\u003c")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta name="color-scheme" content="light">
<title>DataX.now Briefcase</title>
<style>
* {{ box-sizing: border-box; }}
body {{ min-height: 100vh; margin: 0; padding: 32px 16px; background: linear-gradient(145deg, #eff6ff, #f8fafc 55%, #eef2ff); color: #172033; font: 16px/1.55 system-ui, sans-serif; }}
main {{ max-width: 760px; margin: 0 auto; padding: clamp(22px, 5vw, 42px); background: #fff; border: 1px solid #dce5f1; border-radius: 22px; box-shadow: 0 18px 55px #1e3a5f18; }}
.topbar {{ display: flex; justify-content: space-between; gap: 12px; align-items: center; margin-bottom: 28px; }}
.brand {{ color: #52647d; font-size: .85rem; font-weight: 700; letter-spacing: .04em; }}
.tools {{ display: flex; gap: 8px; }}
button, a.button {{ font: inherit; }}
.tool {{ display: inline-block; border: 1px solid #cbd5e1; background: #fff; color: #334155; border-radius: 999px; padding: 7px 13px; cursor: pointer; text-decoration: none; }}
h1 {{ margin: 0 0 10px; font-size: clamp(1.65rem, 5vw, 2.25rem); line-height: 1.2; }}
.intro {{ margin: 0 0 24px; color: #52647d; }}
.section-title {{ margin: 24px 0 10px; font-size: 1rem; }}
.files {{ margin: 0; padding: 14px 18px 14px 38px; border-radius: 12px; background: #f8fafc; }}
.files li + li {{ margin-top: 3px; }}
.file-summary {{ margin: 0 0 10px; color: #64748b; font-size: .9rem; }}
small, .site-url {{ color: #64748b; }}
.remote-url {{ overflow-wrap: anywhere; }}
.site-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 245px), 1fr)); gap: 12px; }}
.site-option {{ display: flex; flex-direction: column; align-items: flex-start; gap: 3px; min-height: 86px; padding: 14px; border: 1px solid #cbd5e1; border-radius: 14px; background: #fff; color: #172033; cursor: pointer; text-align: left; }}
.site-option:hover, .site-option:focus-visible {{ border-color: #2563eb; outline: 3px solid #2563eb22; }}
.site-option[aria-pressed="true"] {{ border: 2px solid #2563eb; padding: 13px; background: #eff6ff; }}
.site-name {{ font-weight: 750; overflow-wrap: anywhere; }}
.default-badge {{ color: #1d4ed8; font-size: .78rem; font-weight: 700; }}
a.button {{ display: inline-flex; justify-content: center; width: 100%; margin-top: 18px; padding: 12px 18px; border: 0; border-radius: 12px; background: #1d4ed8; color: #fff; font-weight: 750; text-decoration: none; cursor: pointer; }}
a.button:hover {{ background: #1e40af; }}
#status {{ margin: 10px 0 0; color: #52647d; }}
#parts {{ padding-left: 24px; }}
#parts li {{ margin: 8px 0; }}
.guidance {{ margin: 16px 0 20px; padding: 16px 18px; border: 1px solid #bfdbfe; border-radius: 14px; background: #eff6ff; }}
.guidance h3 {{ margin: 0 0 8px; font-size: 1rem; }}
.guidance ol {{ margin: 0; padding-left: 22px; }}
.guidance li + li {{ margin-top: 5px; }}
.guidance p {{ margin: 10px 0 0; color: #52647d; }}
button:focus-visible, a:focus-visible {{ outline: 3px solid #f59e0b; outline-offset: 3px; }}
@media (prefers-reduced-motion: no-preference) {{ main {{ animation: arrive .35s ease-out; }} @keyframes arrive {{ from {{ opacity: 0; transform: translateY(8px); }} to {{ opacity: 1; transform: none; }} }} }}
</style>
</head>
<body>
<main>
<div class="topbar">
<div class="brand" data-i18n="brand">DataX.now Briefcase</div>
<div class="tools"><button class="tool" id="language" type="button" aria-label="Switch language">中文</button></div>
</div>
<h1 id="title"></h1>
<h2 class="section-title" data-i18n="filesTitle">Containing Files</h2>
<p id="file-summary" class="file-summary"></p>
<ul class="files">
{items}
</ul>
<section aria-labelledby="sites-title">
<h2 class="section-title" id="sites-title" data-i18n="sitesTitle">Choose a site</h2>
<p class="intro" id="summary" data-i18n="summary"></p>
<p class="intro" data-i18n="sitesHint">The first site is selected by default. Choose another if it is unavailable.</p>
<div id="guide" class="guidance">
<h3 id="guide-title" data-i18n="guideTitle">Before you continue</h3>
<ol>
<li data-i18n="guideStep1">Choose the site you want to use.</li>
<li data-i18n="guideStep2">The site will ask you to confirm before saving these files in its browser storage.</li>
<li data-i18n="guideStep3">Your files travel in the web address after the # and are not sent to the site server.</li>
</ol>
<p id="remote-guidance" data-i18n="remoteGuidance" hidden></p>
<p id="large-guidance" data-i18n="largeGuidance" hidden></p>
<p id="status" role="status" aria-live="polite" hidden></p>
<ol id="parts" hidden></ol>
</div>
<div id="sites" class="site-grid"></div>
<a id="open" class="button" href="#"></a>
</section>
</main>
<script id="briefcase-link" type="application/json">{config}</script>
<script>
const config = JSON.parse(document.getElementById('briefcase-link').textContent);
const open = document.getElementById('open');
const status = document.getElementById('status');
const parts = document.getElementById('parts');
const sites = document.getElementById('sites');
const largeGuidance = document.getElementById('large-guidance');
const remoteGuidance = document.getElementById('remote-guidance');
const languageButton = document.getElementById('language');
const translations = {{
  en: {{
    brand: 'DataX.now Briefcase', titleLauncher: 'Briefcase {{name}}', titleFiles: 'Briefcase files',
    fileSummary: '{{count}} {{fileWord}} · {{bytes}} {{byteWord}} total',
    remoteSummary: '{{count}} downloaded when opened', remoteItem: 'downloaded when opened from',
    remoteGuidance: 'Files marked as downloaded are not stored in this launcher. The site fetches them from the addresses listed above when you open it, so you need to be online and those servers must allow it. The site will ask you to confirm these addresses first. If a download fails or you skip it, the other files are still imported; you can save the external files from their addresses and upload them in the site yourself.',
    summary: 'Choose where you would like to open these files. The site will ask you to confirm before saving them to its browser storage.',
    filesTitle: 'Containing Files', sitesTitle: 'Choose a site', sitesHint: 'The first site is selected by default. Choose another if it is unavailable.',
    open: 'Open these files in {{host}}', default: 'Default', guideTitle: 'Before you continue',
    guideStep1: 'Choose the site you want to use.',
    guideStep2: 'The site will ask you to confirm before saving these files in its browser storage.',
    guideStep3: 'Your files travel in the web address after the # and are not sent to the site server.',
    largeGuidance: 'For larger file packages, your browser may ask you to allow pop-up windows.',
    blocked: 'Your browser blocked the pop-up windows. Open the links below to continue, or allow pop-ups for this page and try again.',
    opened: 'Opened {{count}} tabs. Your files will be ready in one of them.', part: 'Part {{index}} of {{count}}', openPart: 'Open'
  }},
  zh: {{
    brand: 'DataX.now 文件助手', titleLauncher: 'Briefcase {{name}}', titleFiles: 'Briefcase 文件',
    fileSummary: '共 {{count}} 个文件 · {{bytes}} 字节',
    remoteSummary: '{{count}} 个文件将在打开时下载', remoteItem: '打开时下载自',
    remoteGuidance: '标记为下载的文件并未保存在此启动文件中。打开时，站点会从上方列出的地址获取它们，因此需要联网，且这些服务器必须允许访问。站点会先请您确认这些地址。如果下载失败或您选择跳过，其他文件仍会导入；您可以自行从这些地址保存文件，再上传到站点。',
    summary: '请选择要打开文件的站点。站点会在将文件保存到浏览器存储前请求确认。',
    filesTitle: '包含文件', sitesTitle: '选择站点', sitesHint: '默认已选第一个站点。如果无法访问，请选择其他站点。',
    open: '在 {{host}} 中打开这些文件', default: '默认', guideTitle: '开始之前',
    guideStep1: '选择您想使用的站点。',
    guideStep2: '站点会先征求确认，然后将这些文件保存到该站点的浏览器存储中。',
    guideStep3: '文件通过网址中 # 后的内容传递，不会发送给站点服务器。',
    largeGuidance: '打开较大的文件包时，浏览器可能会询问是否允许弹出窗口。',
    blocked: '浏览器拦截了弹出窗口。请打开下方链接继续，或允许此页面打开弹出窗口后重试。',
    opened: '已打开 {{count}} 个窗口，文件将在其中一个窗口中打开。', part: '第 {{index}} / {{count}} 段', openPart: '打开'
  }}
}};
let language = navigator.language.toLowerCase().startsWith('zh') ? 'zh' : 'en';
let chosen = config.hosts[0];
const hostName = host => new URL(host).hostname === 'datax.now' ? 'DataX.now' : new URL(host).hostname;
// Only the site changes between alternatives; each link keeps the same fragment.
const linkFor = (host, index) => host + config.urls[index].slice(config.urls[index].indexOf('#'));

function text(key, values = {{}}) {{
  return Object.entries(values).reduce((result, [name, value]) => result.replace('{{' + name + '}}', value), translations[language][key]);
}}

function applyLanguage() {{
  document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
  const title = text('titleLauncher', {{name: config.launcherName}});
  document.getElementById('title').textContent = title;
  document.title = title + ' - ' + translations[language].brand;
  document.querySelectorAll('[data-i18n]').forEach(element => {{
    element.textContent = translations[language][element.dataset.i18n];
  }});
  const count = config.fileCount.toLocaleString(language === 'zh' ? 'zh-CN' : 'en');
  const bytes = config.totalBytes.toLocaleString(language === 'zh' ? 'zh-CN' : 'en');
  const summary = [];
  if (config.fileCount > 0 || config.remoteCount === 0) {{
    summary.push(language === 'zh'
      ? text('fileSummary', {{count, bytes}})
      : text('fileSummary', {{
        count,
        fileWord: config.fileCount === 1 ? 'file' : 'files',
        bytes,
        byteWord: config.totalBytes === 1 ? 'byte' : 'bytes'
      }}));
  }}
  if (config.remoteCount > 0) {{
    summary.push(text('remoteSummary', {{count: config.remoteCount.toLocaleString(language === 'zh' ? 'zh-CN' : 'en')}}));
  }}
  document.getElementById('file-summary').textContent = summary.join(' · ');
  remoteGuidance.hidden = config.remoteCount === 0;
  document.getElementById('summary').textContent = translations[language].summary;
  largeGuidance.hidden = config.urls.length === 1;
  languageButton.textContent = language === 'zh' ? 'English' : '中文';
  languageButton.setAttribute('aria-label', language === 'zh' ? 'Switch to English' : '切换到中文');
  open.textContent = text('open', {{host: hostName(chosen)}});
  document.querySelectorAll('.default-badge').forEach(badge => badge.textContent = translations[language].default);
  status.textContent = status.dataset.message
    ? status.dataset.message === 'opened'
      ? text('opened', {{count: status.dataset.count}})
      : translations[language][status.dataset.message]
    : '';
  parts.querySelectorAll('[data-part]').forEach(link => {{
    const [index, count] = link.dataset.part.split(',').map(Number);
    link.textContent = count > 1 ? text('part', {{index: index + 1, count}}) : text('openPart');
  }});
}}

function selectSite(host) {{
  chosen = host;
  sites.querySelectorAll('.site-option').forEach(button => {{
    button.setAttribute('aria-pressed', button.dataset.host === host ? 'true' : 'false');
  }});
  open.href = linkFor(host, 0);
  applyLanguage();
}}

for (const [index, host] of config.hosts.entries()) {{
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'site-option';
  button.dataset.host = host;
  button.setAttribute('aria-pressed', index === 0 ? 'true' : 'false');
  const name = document.createElement('span');
  name.className = 'site-name';
  name.textContent = hostName(host);
  const url = document.createElement('span');
  url.className = 'site-url';
  url.textContent = new URL(host).pathname;
  button.append(name, url);
  if (index === 0) {{
    const badge = document.createElement('span');
    badge.className = 'default-badge';
    button.append(badge);
  }}
  button.addEventListener('click', () => selectSite(host));
  sites.append(button);
}}

function setStatus(message) {{
  status.dataset.message = message;
  status.hidden = false;
  applyLanguage();
}}

// Clicks on links are never blocked, so each part gets a plain link when pop-ups are refused.
function showPartLinks() {{
  if (parts.hasChildNodes()) {{
    return;
  }}
  config.urls.forEach((_url, index) => {{
    const link = document.createElement('a');
    link.href = linkFor(chosen, index);
    link.target = '_blank';
    link.rel = 'noopener';
    link.dataset.part = index + ',' + config.urls.length;
    const item = document.createElement('li');
    item.appendChild(link);
    parts.appendChild(item);
  }});
  parts.hidden = false;
  applyLanguage();
}}

open.href = linkFor(chosen, 0);
open.addEventListener('click', event => {{
  if (config.urls.length === 1) {{
    return;
  }}
  event.preventDefault();
  status.hidden = true;
  delete status.dataset.message;
  delete status.dataset.count;
  parts.replaceChildren();
  parts.hidden = true;
  const opened = [];
  for (let index = 0; index < config.urls.length; index++) {{
    const url = linkFor(chosen, index);
    const tab = window.open(url, '_blank');
    if (tab === null) {{
      opened.forEach(earlier => earlier.close());
      setStatus('blocked');
      showPartLinks();
      return;
    }}
    tab.opener = null;
    opened.push(tab);
  }}
  status.dataset.count = opened.length;
  setStatus('opened');
}});
function toggleLanguage() {{
  language = language === 'zh' ? 'en' : 'zh';
  applyLanguage();
}}
languageButton.addEventListener('click', toggleLanguage);
selectSite(chosen);
if (config.redirect) {{
  location.replace(open.href);
}}
applyLanguage();
</script>
</body>
</html>
"""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument(
        "paths",
        nargs="+",
        metavar="path-or-url",
        help=(
            "Notebook/companion files, or one directory to include recursively (hidden entries are skipped). "
            "An https:// URL, optionally written NAME=URL, is not embedded: the site downloads it when the link "
            "is opened, which needs CORS on the URL's server."
        ),
    )
    parser.add_argument(
        "--app-url",
        action="append",
        default=None,
        help="Hosted app page (repeat to offer a choice; defaults to DataX and its Read the Docs mirror).",
    )
    parser.add_argument("--open", dest="notebook", help="Notebook to open, relative to the included files (default: first .ipynb)")
    parser.add_argument("--output", type=Path, help="HTML file to write (default: named after the embedded files in the current directory, see docs)")
    parser.add_argument("--no-redirect", action="store_true", help="Show a button instead of navigating automatically")
    args = parser.parse_args(argv)
    try:
        remote_arguments = [argument for argument in args.paths if REMOTE_ARGUMENT.fullmatch(argument)]
        remote = collect_remote(remote_arguments)
        local_paths = [Path(argument) for argument in args.paths if argument not in remote_arguments]
        sources = collect_sources(local_paths, list(remote))
        files = {name: path.read_bytes() for name, path in sources.items()}
        notebooks = [name for name in [*files, *remote] if name.lower().endswith(".ipynb")]
        notebook = args.notebook or (notebooks[0] if notebooks else "")
        hosts = list(dict.fromkeys(args.app_url or DEFAULT_APP_URLS))
        output = args.output or Path(default_output_name(sources, hosts[0], list(remote)))
        upgraded = upgrade_notebooks(files)
        converted = [name for name in files if upgraded[name] != files[name]]
        files = upgraded
        urls = build_links(hosts, files, notebook, output.name, remote)
        output.write_text(
            render_html(urls, files, notebook, not args.no_redirect, hosts, output.name, remote),
            encoding="utf-8",
        )
    except (OSError, ValueError) as error:
        print(f"Could not create link: {error}", file=sys.stderr)
        return 1
    if converted:
        print(f"Converted to nbformat 4.5 in the link (source files unchanged): {', '.join(converted)}")
    size = sum(map(len, urls))
    embedded = f"{len(files)} file(s)" + (f" + {len(remote)} external" if remote else "")
    if len(urls) > 1:
        print(
            f"Wrote {output} ({embedded} in {len(urls)} linked parts, {size:,} characters, "
            f"opens {notebook or 'no notebook'}). Open it and click the button; the parts merge automatically."
        )
    else:
        print(f"Wrote {output} ({embedded}, link {size:,} characters, opens {notebook or 'no notebook'}).")
    if remote:
        print(
            f"Downloaded when the link is opened, not embedded: {', '.join(remote)}. "
            "Each server must allow cross-origin (CORS) requests."
        )
    if any(len(url) >= FIREFOX_URL_LIMIT for url in urls):
        print("Warning: links over 1 MiB do not open in Firefox's default configuration.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
