"""Register the prebuilt JupyterLite Briefcase extensions."""

from __future__ import annotations


def _jupyter_labextension_paths():
    return [
        {"src": "labextension", "dest": "@jupyterlite/briefcase"},
        {"src": "export-labextension", "dest": "@jupyterlite/briefcase-export"},
    ]
