// src/protocol.ts
var PROTOCOL = "jupyterlab-local-notebook-import";
var VERSION = 1;
var DEFAULT_LIMIT = 20 * 1024 * 1024;
var DEFAULT_BUNDLE_LIMIT = 100 * 1024 * 1024;
var DEFAULT_BUNDLE_FILES = 256;
var MAX_BUNDLE_DEPTH = 16;
var CONNECTION_TIMEOUT = 12e4;
var SESSION_TIMEOUT = 10 * 6e4;
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function validId(value) {
  return typeof value === "string" && /^[a-zA-Z0-9_-]{1,128}$/.test(value);
}
function parseEnvelope(value) {
  if (!isRecord(value) || value.protocol !== PROTOCOL || value.version !== VERSION || !validId(value.sessionId) || value.requestId !== void 0 && !validId(value.requestId) || typeof value.type !== "string" || !isRecord(value.payload)) {
    return null;
  }
  return {
    protocol: PROTOCOL,
    version: VERSION,
    sessionId: value.sessionId,
    requestId: value.requestId,
    type: value.type,
    payload: value.payload
  };
}
function envelope(sessionId, type, payload, requestId) {
  return {
    protocol: PROTOCOL,
    version: VERSION,
    sessionId,
    requestId,
    type,
    payload
  };
}
function validBasename(value) {
  return value.length > 0 && value.length <= 255 && value !== "." && value !== ".." && !/[\\/\u0000-\u001f\u007f]/.test(value);
}
function parseOffer(value) {
  if (typeof value.filename !== "string" || !validBasename(value.filename) || !value.filename.toLowerCase().endsWith(".ipynb") || typeof value.byteLength !== "number" || !Number.isSafeInteger(value.byteLength) || value.byteLength <= 0) {
    return null;
  }
  return { filename: value.filename, byteLength: value.byteLength };
}
function parseResult(value) {
  if (value.status === "opened" && typeof value.savedPath === "string") {
    return { status: "opened", savedPath: value.savedPath };
  }
  if (value.status === "saved" && typeof value.savedPath === "string" && (value.warningCode === "OPEN_FAILED" || value.warningCode === "NO_NOTEBOOK")) {
    return {
      status: "saved",
      savedPath: value.savedPath,
      warningCode: value.warningCode
    };
  }
  if (value.status === "error" && typeof value.code === "string" && (value.savedPath === void 0 || typeof value.savedPath === "string") && (value.savedPaths === void 0 || Array.isArray(value.savedPaths) && value.savedPaths.every((path) => typeof path === "string"))) {
    return {
      status: "error",
      code: value.code,
      savedPath: value.savedPath,
      savedPaths: value.savedPaths
    };
  }
  return null;
}
function trustedUrl(value, base) {
  const url = new URL(value, base);
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && loopback) || url.username || url.password) {
    throw new Error("Use HTTPS, or HTTP on loopback, without URL credentials.");
  }
  return url;
}
function validRelativePath(value) {
  if (value.length === 0 || value.length > 1024 || value.startsWith("/")) {
    return false;
  }
  const parts = value.split("/");
  return parts.length <= MAX_BUNDLE_DEPTH && parts.every(validBasename) && !value.includes(":");
}

// src/launcher.ts
function element(id, type) {
  const node = document.getElementById(id);
  if (!(node instanceof type)) {
    throw new Error(`Missing launcher element: ${id}`);
  }
  return node;
}
var status = element("status", HTMLParagraphElement);
function start() {
  trustedUrl(location.href);
  const configElement = element("briefcase-config", HTMLScriptElement);
  const config = JSON.parse(configElement.textContent ?? "");
  if (!isRecord(config) || typeof config.appUrl !== "string") {
    throw new Error("Configure appUrl in the exported launcher.");
  }
  const appUrl = trustedUrl(config.appUrl, location.href);
  if (appUrl.hash || appUrl.search) {
    throw new Error("appUrl must not contain a query or fragment.");
  }
  const frame = element("jupyter", HTMLIFrameElement);
  const picker = element("notebook", HTMLInputElement);
  const folderPicker = element("bundle", HTMLInputElement);
  const notebookPicker = element("bundle-notebook", HTMLSelectElement);
  const open = element("open", HTMLButtonElement);
  const check = element("check", HTMLButtonElement);
  const reconnect = element("reconnect", HTMLButtonElement);
  const selection = element("selection", HTMLParagraphElement);
  const destination = element("destination", HTMLParagraphElement);
  let sessionId = crypto.randomUUID();
  let ready = false;
  let limit = DEFAULT_LIMIT;
  let bundleLimit = DEFAULT_BUNDLE_LIMIT;
  let bundleFileLimit = DEFAULT_BUNDLE_FILES;
  let selected;
  let bundle;
  let active;
  let retryBlocked = performance.getEntriesByType("navigation").some(
    (entry) => entry instanceof PerformanceNavigationTiming && (entry.type === "reload" || entry.type === "back_forward")
  );
  let connectedOnce = false;
  let handshakeStart = 0;
  let handshake;
  let resultTimer;
  function update() {
    open.disabled = !ready || !selected && !bundle || !!active || retryBlocked;
    picker.disabled = !!active;
    folderPicker.disabled = !!active;
    notebookPicker.disabled = !!active || !bundle;
    check.disabled = !ready || !active;
    reconnect.disabled = !!active;
  }
  function send(type, payload, requestId) {
    frame.contentWindow?.postMessage(
      envelope(sessionId, type, payload, requestId),
      appUrl.origin
    );
  }
  function offerValid(file) {
    if (!parseOffer({ filename: file.name, byteLength: file.size })) {
      status.textContent = "Select a non-empty .ipynb file with a valid filename.";
      return false;
    }
    if (file.size > limit) {
      status.textContent = `FILE_TOO_LARGE: maximum size is ${limit} bytes.`;
      return false;
    }
    return true;
  }
  function beginHandshake() {
    clearInterval(handshake);
    clearTimeout(resultTimer);
    if (active) {
      retryBlocked = true;
      active = void 0;
    }
    ready = false;
    sessionId = crypto.randomUUID();
    handshakeStart = Date.now();
    status.textContent = retryBlocked ? "Connection reset or launcher reloaded. Inspect the destination before reconnecting or importing another copy." : "Connecting to JupyterLite. Sign in inside the frame if required.";
    const hello = () => {
      if (Date.now() - handshakeStart >= CONNECTION_TIMEOUT) {
        clearInterval(handshake);
        status.textContent = "Connection timed out. Check the host extension, trusted-origin policy, framing, and authentication, then reconnect.";
        return;
      }
      send("HELLO", {});
    };
    hello();
    handshake = setInterval(hello, 1e3);
    update();
  }
  function prepareBundle() {
    const localFiles = Array.from(folderPicker.files ?? []);
    if (localFiles.length < 2 || localFiles.length > bundleFileLimit) {
      status.textContent = `Select a folder with 2\u2013${bundleFileLimit} files, including a notebook.`;
      return void 0;
    }
    const root = localFiles[0].webkitRelativePath.split("/")[0];
    if (!root || localFiles.some((file) => !file.webkitRelativePath.startsWith(`${root}/`))) {
      status.textContent = "The selected folder has invalid relative paths.";
      return void 0;
    }
    const files = [];
    const paths = /* @__PURE__ */ new Set();
    let totalByteLength = 0;
    for (const file of localFiles) {
      const path = file.webkitRelativePath.slice(root.length + 1);
      if (!validRelativePath(path) || paths.has(path)) {
        status.textContent = "The selected folder has an unsafe or duplicate relative path.";
        return void 0;
      }
      if (path.toLowerCase().endsWith(".ipynb")) {
        if (!offerValid(file)) {
          return void 0;
        }
      }
      paths.add(path);
      totalByteLength += file.size;
      if (!Number.isSafeInteger(totalByteLength) || totalByteLength > bundleLimit) {
        status.textContent = `BUNDLE_TOO_LARGE: maximum total size is ${bundleLimit} bytes.`;
        return void 0;
      }
      files.push({ path, file });
    }
    const notebooks = files.filter(
      (item) => item.path.toLowerCase().endsWith(".ipynb")
    );
    if (!notebooks.length) {
      status.textContent = "The selected folder must contain at least one .ipynb notebook.";
      return void 0;
    }
    const current = notebookPicker.value;
    notebookPicker.replaceChildren(
      ...notebooks.map((item) => {
        const option = document.createElement("option");
        option.value = item.path;
        option.textContent = item.path;
        return option;
      })
    );
    if (notebooks.some((item) => item.path === current)) {
      notebookPicker.value = current;
    }
    notebookPicker.hidden = false;
    return {
      files,
      entries: files.map(({ path, file }) => ({ path, byteLength: file.size })),
      totalByteLength
    };
  }
  function bundleSelection() {
    if (!bundle) {
      return void 0;
    }
    const notebookPath = notebookPicker.value;
    const selectedNotebook = bundle.files.find(
      (item) => item.path === notebookPath
    );
    if (!selectedNotebook || !offerValid(selectedNotebook.file)) {
      return void 0;
    }
    return { ...bundle, notebookPath };
  }
  folderPicker.addEventListener("change", () => {
    selected = void 0;
    picker.value = "";
    bundle = prepareBundle();
    if (!bundle) {
      notebookPicker.replaceChildren();
      notebookPicker.hidden = true;
    }
    selection.textContent = bundle ? `${bundle.files.length} files (${bundle.totalByteLength} bytes). Choose which notebook to open.` : "No folder selected.";
    status.textContent = bundle ? "Folder selected. Choose the notebook and request import confirmation." : status.textContent;
    update();
  });
  notebookPicker.addEventListener("change", update);
  picker.addEventListener("change", () => {
    bundle = void 0;
    folderPicker.value = "";
    notebookPicker.replaceChildren();
    notebookPicker.hidden = true;
    const file = picker.files?.[0];
    selected = file && offerValid(file) ? file : void 0;
    selection.textContent = file ? `${file.name} (${file.size} bytes)` : "No notebook selected.";
    if (selected) {
      status.textContent = retryBlocked ? "Notebook selected. Inspect the destination and use Reconnect before importing another copy." : "Notebook selected. Open it to request import confirmation.";
    }
    update();
  });
  open.addEventListener("click", () => {
    if (!ready || !selected && !bundle || active || retryBlocked || selected !== void 0 && !offerValid(selected)) {
      return;
    }
    const chosenBundle = bundleSelection();
    if (!selected && !chosenBundle) {
      return;
    }
    active = {
      id: crypto.randomUUID(),
      file: chosenBundle ? void 0 : selected,
      bundle: chosenBundle,
      sent: false
    };
    status.textContent = "Waiting for confirmation inside JupyterLite.";
    if (chosenBundle) {
      send(
        "IMPORT_OFFER",
        {
          kind: "bundle",
          filename: chosenBundle.notebookPath.split("/").at(-1),
          notebookPath: chosenBundle.notebookPath,
          entries: chosenBundle.entries,
          totalByteLength: chosenBundle.totalByteLength
        },
        active.id
      );
    } else {
      send(
        "IMPORT_OFFER",
        { filename: selected.name, byteLength: selected.size },
        active.id
      );
    }
    resultTimer = setTimeout(() => {
      status.textContent = "No final result received. Check import status; do not resend. If the frame reloaded, inspect the destination before retrying.";
    }, CONNECTION_TIMEOUT + 5e3);
    update();
  });
  check.addEventListener("click", () => {
    if (active) {
      send("STATUS_QUERY", {}, active.id);
    }
  });
  reconnect.addEventListener("click", () => {
    if (retryBlocked && !window.confirm(
      "Have you inspected the destination for an existing imported copy? Reconnecting permits a new import, which may create another copy."
    )) {
      return;
    }
    retryBlocked = false;
    beginHandshake();
  });
  window.addEventListener("message", async (event) => {
    if (event.origin !== appUrl.origin || event.source !== frame.contentWindow) {
      return;
    }
    const message = parseEnvelope(event.data);
    if (!message || message.sessionId !== sessionId) {
      return;
    }
    if (message.type === "READY" && message.requestId === void 0) {
      const max = message.payload.maxNotebookBytes;
      const maxBundle = message.payload.maxBundleBytes;
      const maxFiles = message.payload.maxBundleFiles;
      const directory = message.payload.destinationDirectory;
      if (typeof max !== "number" || !Number.isSafeInteger(max) || max <= 0 || typeof maxBundle !== "number" || !Number.isSafeInteger(maxBundle) || maxBundle < max || typeof maxFiles !== "number" || !Number.isSafeInteger(maxFiles) || maxFiles < 2 || typeof directory !== "string" || message.payload.notebookFormat !== "4.5") {
        status.textContent = "Invalid or unsupported receiver capabilities.";
        return;
      }
      clearInterval(handshake);
      ready = true;
      connectedOnce = true;
      limit = max;
      bundleLimit = maxBundle;
      bundleFileLimit = maxFiles;
      destination.textContent = `Destination: ${directory}. Notebook format: 4.5. Notebook maximum: ${max} bytes. Bundle maximum: ${maxBundle} bytes across ${maxFiles} files.`;
      status.textContent = retryBlocked ? "Connected. Inspect the destination, then use Reconnect to acknowledge recovery before another import." : "Ready. Select a notebook to import a copy.";
      if (selected && !offerValid(selected)) {
        selected = void 0;
      }
      update();
      return;
    }
    if (message.type === "CONNECTION_ERROR") {
      if (message.payload.code === "BUSY" && !ready) {
        status.textContent = "The receiver is finishing an earlier import. Waiting to reconnect.";
        return;
      }
      ready = false;
      clearTimeout(resultTimer);
      if (active) {
        active = void 0;
        retryBlocked = true;
      }
      status.textContent = `Connection unavailable (${String(message.payload.code)}). Inspect any pending import before reconnecting.`;
      update();
      return;
    }
    const request = active;
    if (!request || message.requestId !== request.id) {
      return;
    }
    if (message.type === "IMPORT_ACCEPT" && !request.sent) {
      request.sent = true;
      status.textContent = request.bundle ? "Transferring the selected folder and saving a copy." : "Transferring notebook and saving a copy.";
      try {
        if (request.bundle) {
          const files = [];
          for (const item of request.bundle.files) {
            files.push({
              path: item.path,
              buffer: await item.file.arrayBuffer()
            });
          }
          if (active !== request || message.sessionId !== sessionId || !ready) {
            return;
          }
          frame.contentWindow?.postMessage(
            envelope(sessionId, "IMPORT_DATA", { files }, request.id),
            appUrl.origin,
            files.map((item) => item.buffer)
          );
          return;
        }
        const buffer = await request.file.arrayBuffer();
        if (active !== request || message.sessionId !== sessionId || !ready) {
          return;
        }
        frame.contentWindow?.postMessage(
          envelope(sessionId, "IMPORT_DATA", { buffer }, request.id),
          appUrl.origin,
          [buffer]
        );
      } catch {
        if (active === request) {
          send("CANCEL", {}, request.id);
          status.textContent = "FILE_READ_FAILED: the selected file could not be transferred. Check status before retrying.";
        }
      }
    } else if (message.type === "IMPORT_STATUS") {
      status.textContent = `Import status: ${String(message.payload.state)}.`;
    } else if (message.type === "IMPORT_RESULT") {
      const result = parseResult(message.payload);
      if (!result) {
        status.textContent = "Invalid import result. Check status before retrying.";
        return;
      }
      clearTimeout(resultTimer);
      active = void 0;
      if (result.status === "opened") {
        status.textContent = `Opened ${result.savedPath}. The original file is unchanged.`;
        selected = void 0;
        picker.value = "";
        bundle = void 0;
        folderPicker.value = "";
        notebookPicker.replaceChildren();
        notebookPicker.hidden = true;
        selection.textContent = "Select a file or folder again only to import another copy.";
      } else if (result.status === "saved") {
        status.textContent = result.warningCode === "NO_NOTEBOOK" ? `Saved files in ${result.savedPath}. No notebook was included, so nothing was opened.` : `Saved ${result.savedPath}, but opening failed (OPEN_FAILED). Open that copy from JupyterLite's file browser.`;
        retryBlocked = true;
      } else {
        status.textContent = `Import failed (${result.code}).${result.savedPath ? ` Allocated path: ${result.savedPath}. Inspect it before retrying.` : ""}${result.savedPaths?.length ? ` Saved files: ${result.savedPaths.join(", ")}.` : ""}`;
        if (result.code === "DESTINATION_MISSING") {
          status.textContent += " Create the configured destination directory in the app file browser, then retry.";
        }
        retryBlocked = !!result.savedPath || result.code === "UNKNOWN_REQUEST" || result.code === "ALLOCATION_FAILED";
      }
      update();
    }
  });
  frame.addEventListener("load", () => {
    if (connectedOnce || active) {
      retryBlocked = !!active || retryBlocked;
    }
    beginHandshake();
  });
  frame.src = appUrl.href;
  beginHandshake();
}
try {
  start();
} catch (error) {
  status.textContent = `Launcher unavailable: ${error instanceof Error ? error.message : "invalid configuration"}`;
}
