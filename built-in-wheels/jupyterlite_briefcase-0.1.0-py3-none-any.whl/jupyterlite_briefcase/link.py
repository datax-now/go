"""Generate a local HTML file that hands notebooks to a hosted JupyterLite site.

The file can be opened directly from disk (``file://``). It navigates to the
hosted app with the files compressed into the URL fragment; the Briefcase
receiver on that site asks for confirmation and saves a copy in the site's
browser storage, where the kernel and file browser can use it.
"""

from __future__ import annotations

import argparse
import base64
import html
import json
import struct
import sys
import zlib
from pathlib import Path
from urllib.parse import urlsplit

LINK_KEY = "briefcase-import"
LINK_VERSION = "1"
MAX_DEPTH = 16
# Chromium rejects navigations to URLs longer than 2 MiB; Firefox's default is 1 MiB.
CHROMIUM_URL_LIMIT = 2 * 1024 * 1024
FIREFOX_URL_LIMIT = 1024 * 1024
LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}


def _valid_part(part: str) -> bool:
    return (
        0 < len(part) <= 255
        and part not in {".", ".."}
        and not any(ord(char) < 32 or ord(char) == 127 or char in "\\/:" for char in part)
    )


def validate_app_url(app_url: str) -> str:
    parsed = urlsplit(app_url)
    secure = parsed.scheme == "https" or (parsed.scheme == "http" and parsed.hostname in LOOPBACK_HOSTS)
    if not secure or not parsed.netloc or parsed.username or parsed.password or parsed.fragment or "\\" in app_url:
        raise ValueError("--app-url must be an absolute HTTPS (or loopback HTTP) URL without credentials or fragment")
    return app_url


def collect_files(paths: list[Path]) -> dict[str, bytes]:
    """Read one directory recursively, or a list of individual files."""
    files: dict[str, bytes] = {}
    if len(paths) == 1 and paths[0].is_dir():
        root = paths[0]
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if any(part.startswith(".") for part in relative.parts) or not path.is_file():
                continue
            files[relative.as_posix()] = path.read_bytes()
    else:
        for path in paths:
            if not path.is_file():
                raise ValueError(f"{path} is not a file (pass a single directory to include a folder)")
            if path.name in files:
                raise ValueError(f"duplicate file name {path.name}")
            files[path.name] = path.read_bytes()
    if not files:
        raise ValueError("no files to include")
    seen: set[str] = set()
    for name in files:
        parts = name.split("/")
        if len(parts) > MAX_DEPTH or len(name) > 1024 or not all(map(_valid_part, parts)):
            raise ValueError(f"unsupported path {name!r}")
        if name.lower() in seen:
            raise ValueError(f"paths differ only by case: {name!r}")
        seen.add(name.lower())
    return files


def check_notebook(name: str, data: bytes) -> None:
    try:
        notebook = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise ValueError(f"{name} is not valid notebook JSON: {error}") from None
    if not isinstance(notebook, dict) or (notebook.get("nbformat"), notebook.get("nbformat_minor")) != (4, 5):
        raise ValueError(
            f"{name} is not nbformat 4.5; the receiver only accepts 4.5. "
            "Convert it first, for example with: jupyter nbconvert --to notebook --inplace " + name
        )
    cells = notebook.get("cells")
    if not isinstance(cells, list) or not all(isinstance(cell, dict) and isinstance(cell.get("id"), str) for cell in cells):
        raise ValueError(f"{name} has cells without ids, which nbformat 4.5 requires")


def encode_payload(files: dict[str, bytes], notebook_path: str) -> str:
    """base64url(deflate-raw(u32 header length + JSON header + file bytes))."""
    header = json.dumps(
        {
            "notebookPath": notebook_path,
            "entries": [{"path": path, "byteLength": len(data)} for path, data in files.items()],
        },
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
    raw = struct.pack(">I", len(header)) + header + b"".join(files.values())
    compressed = compressor.compress(raw) + compressor.flush()
    return base64.urlsafe_b64encode(compressed).rstrip(b"=").decode("ascii")


def build_link(app_url: str, files: dict[str, bytes], notebook_path: str) -> str:
    validate_app_url(app_url)
    if notebook_path not in files or not notebook_path.lower().endswith(".ipynb"):
        raise ValueError(f"notebook to open {notebook_path!r} is not one of the included .ipynb files")
    for name, data in files.items():
        if name.lower().endswith(".ipynb"):
            check_notebook(name, data)
    return f"{app_url}#{LINK_KEY}={LINK_VERSION}.{encode_payload(files, notebook_path)}"


def render_html(url: str, files: dict[str, bytes], notebook_path: str, redirect: bool = True) -> str:
    target = urlsplit(url)
    site = f"{target.scheme}://{target.netloc}"
    total = sum(map(len, files.values()))
    items = "\n".join(
        f"<li>{html.escape(name)} <small>({len(data):,} bytes)</small></li>" for name, data in files.items()
    )
    config = json.dumps({"url": url, "redirect": redirect}).replace("<", "\\u003c")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>Open {html.escape(notebook_path)} in {html.escape(target.netloc)}</title>
<style>
body {{ font: 15px/1.5 system-ui, sans-serif; margin: 2rem auto; max-width: 42rem; padding: 0 1rem; color: #222; }}
a.button {{ display: inline-block; padding: .5rem 1rem; background: #1565c0; color: #fff; border-radius: 4px; text-decoration: none; }}
small {{ color: #666; }}
</style>
</head>
<body>
<main>
<h1>Open {html.escape(notebook_path)}</h1>
<p>This file opens <strong>{html.escape(site)}</strong> and offers it {len(files)} file(s), {total:,} bytes in total.
The site asks for confirmation, then saves a copy in its browser storage. The files travel in the
address fragment, which is not sent to the server.</p>
<ul>
{items}
</ul>
<p><a id="open" class="button" href="#">Open in {html.escape(target.netloc)}</a></p>
<p id="status"><small>{"Opening&hellip;" if redirect else ""}</small></p>
</main>
<script id="briefcase-link" type="application/json">{config}</script>
<script>
const config = JSON.parse(document.getElementById('briefcase-link').textContent);
document.getElementById('open').href = config.url;
if (config.redirect) {{
  location.replace(config.url);
}}
</script>
</body>
</html>
"""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("paths", nargs="+", type=Path, help="Notebook/companion files, or one directory to include recursively (hidden entries are skipped)")
    parser.add_argument("--app-url", required=True, help="Hosted app page, for example https://datax.now/lab/index.html")
    parser.add_argument("--open", dest="notebook", help="Notebook to open, relative to the included files (default: first .ipynb)")
    parser.add_argument("--output", type=Path, help="HTML file to write (default: <notebook>.html in the current directory)")
    parser.add_argument("--no-redirect", action="store_true", help="Show a button instead of navigating automatically")
    args = parser.parse_args(argv)
    try:
        files = collect_files(args.paths)
        notebooks = [name for name in files if name.lower().endswith(".ipynb")]
        notebook = args.notebook or (notebooks[0] if notebooks else "")
        url = build_link(args.app_url, files, notebook)
        if len(url) >= CHROMIUM_URL_LIMIT:
            raise ValueError(f"the link is {len(url):,} characters; Chromium rejects URLs of 2 MiB or more")
        output = args.output or Path(Path(notebook).stem + ".html")
        output.write_text(render_html(url, files, notebook, not args.no_redirect), encoding="utf-8")
    except (OSError, ValueError) as error:
        print(f"Could not create link: {error}", file=sys.stderr)
        return 1
    print(f"Wrote {output} ({len(files)} file(s), link {len(url):,} characters, opens {notebook}).")
    if len(url) >= FIREFOX_URL_LIMIT:
        print("Warning: links over 1 MiB do not open in Firefox's default configuration.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
