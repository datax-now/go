"""jupyterlite-xeus-x — kernel bundle for JupyterLite."""
__version__ = '20261005.1472.0'
