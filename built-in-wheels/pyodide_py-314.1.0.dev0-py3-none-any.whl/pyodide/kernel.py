"""Jupyter kernel implementation for Pyodide.

This module provides a Python-side implementation of the Jupyter kernel
protocol, built on top of Pyodide's existing :py:class:`~pyodide.console.Console`
infrastructure.

See Also
--------
:py:class:`PyodideKernel`
"""

import traceback
from typing import Any

from .console import COMPLETE, INCOMPLETE, SYNTAX_ERROR, Console

__all__ = ["PyodideKernel"]

# Characters that delimit identifiers/attribute chains in Python source code.
# Used by :py:meth:`PyodideKernel.inspect` to extract the token at the cursor.
_WORD_DELIMITERS = " \t\n`~!@#$%^&*()-=+[{]}\\|;:'\",<>/?"


class PyodideKernel:
    """A Jupyter kernel implementation using Pyodide.

    This class implements the core Jupyter kernel protocol operations —
    execute, complete, inspect, and is_complete — on top of the
    :py:class:`~pyodide.console.Console` class.

    Parameters
    ----------
    globals :
        The global namespace used for code execution. Defaults to a new
        empty dictionary (with ``__name__`` set to ``"__kernel__"``).

    Examples
    --------
    >>> kernel = PyodideKernel()
    >>> import asyncio
    >>> result = asyncio.run(kernel.execute("1 + 1"))
    >>> result["status"]
    'ok'
    >>> result["result"]
    2
    """

    def __init__(self, globals: dict[str, Any] | None = None) -> None:
        if globals is None:
            globals = {"__name__": "__kernel__", "__doc__": None}

        self._execution_count = 0
        self._stdout_parts: list[str] = []
        self._stderr_parts: list[str] = []

        self._console = Console(
            globals=globals,
            stdout_callback=self._stdout_callback,
            stderr_callback=self._stderr_callback,
            persistent_stream_redirection=True,
        )

    # ------------------------------------------------------------------
    # Internal stream helpers
    # ------------------------------------------------------------------

    def _stdout_callback(self, text: str) -> None:
        self._stdout_parts.append(text)

    def _stderr_callback(self, text: str) -> None:
        self._stderr_parts.append(text)

    def _collect_streams(self) -> tuple[str, str]:
        """Return buffered stdout/stderr and clear the buffers."""
        stdout = "".join(self._stdout_parts)
        stderr = "".join(self._stderr_parts)
        self._stdout_parts.clear()
        self._stderr_parts.clear()
        return stdout, stderr

    # ------------------------------------------------------------------
    # Public kernel protocol methods
    # ------------------------------------------------------------------

    async def execute(
        self,
        code: str,
        *,
        silent: bool = False,
        store_history: bool = True,
    ) -> dict[str, Any]:
        """Execute a code string and return the results.

        Parameters
        ----------
        code :
            The source code to execute.
        silent :
            When ``True`` the execution count is not incremented and outputs
            are still captured but the result value is discarded.
        store_history :
            When ``True`` (the default) the execution count is incremented.

        Returns
        -------
        dict
            A dictionary with the following keys:

            ``status``
                ``"ok"`` on success, ``"error"`` on exception,
                ``"incomplete"`` when the code is syntactically incomplete.
            ``execution_count``
                The current execution count (``int``).
            ``stdout``
                Everything written to *stdout* during execution (``str``).
            ``stderr``
                Everything written to *stderr* during execution (``str``).
            ``result``
                The value of the last expression, or ``None``.
            ``ename``
                Exception class name (only present when ``status == "error"``).
            ``evalue``
                Exception message (only present when ``status == "error"``).
            ``traceback``
                Formatted traceback string (only present when
                ``status == "error"``).

        Examples
        --------
        >>> kernel = PyodideKernel()
        >>> import asyncio
        >>> asyncio.run(kernel.execute("x = 42"))["status"]
        'ok'
        >>> asyncio.run(kernel.execute("x"))["result"]
        42
        """
        if not silent and store_history:
            self._execution_count += 1

        execution_count = self._execution_count

        future = self._console.runsource(code)

        if future.syntax_check == INCOMPLETE:
            stdout, stderr = self._collect_streams()
            return {
                "status": "incomplete",
                "execution_count": execution_count,
                "stdout": stdout,
                "stderr": stderr,
                "result": None,
            }

        if future.syntax_check == SYNTAX_ERROR:
            stdout, stderr = self._collect_streams()
            exc = future.exception()
            return {
                "status": "error",
                "execution_count": execution_count,
                "stdout": stdout,
                "stderr": stderr,
                "result": None,
                "traceback": future.formatted_error or "",
                "ename": type(exc).__name__ if exc else "SyntaxError",
                "evalue": str(exc) if exc else "",
            }

        # Code is syntactically complete — wait for async execution to finish.
        assert future.syntax_check == COMPLETE

        try:
            result = await future
        except Exception as exc:
            stdout, stderr = self._collect_streams()
            return {
                "status": "error",
                "execution_count": execution_count,
                "stdout": stdout,
                "stderr": stderr,
                "result": None,
                "traceback": future.formatted_error or traceback.format_exc(),
                "ename": type(exc).__name__,
                "evalue": str(exc),
            }

        stdout, stderr = self._collect_streams()
        return {
            "status": "ok",
            "execution_count": execution_count,
            "stdout": stdout,
            "stderr": stderr,
            "result": None if silent else result,
        }

    def complete(self, code: str, cursor_pos: int) -> dict[str, Any]:
        """Return code completions at the given cursor position.

        Parameters
        ----------
        code :
            The code string to complete.
        cursor_pos :
            Position of the cursor inside *code*.

        Returns
        -------
        dict
            ``status``
                Always ``"ok"``.
            ``matches``
                List of completion strings.
            ``cursor_start``
                Start index (inside *code*) of the token being completed.
            ``cursor_end``
                End index — equals *cursor_pos*.

        Examples
        --------
        >>> kernel = PyodideKernel()
        >>> result = kernel.complete("str.isa", cursor_pos=7)
        >>> result["status"]
        'ok'
        >>> "str.isalpha(" in result["matches"]
        True
        """
        source = code[:cursor_pos]
        completions, start = self._console.complete(source)
        return {
            "status": "ok",
            "matches": completions,
            "cursor_start": start,
            "cursor_end": cursor_pos,
        }

    def inspect(
        self, code: str, cursor_pos: int, detail_level: int = 0
    ) -> dict[str, Any]:
        """Return introspection / documentation for the object at the cursor.

        Parameters
        ----------
        code :
            The code string.
        cursor_pos :
            Cursor position within *code*.
        detail_level :
            ``0`` for basic info, ``1`` for full documentation.

        Returns
        -------
        dict
            ``status``
                Always ``"ok"``.
            ``found``
                ``True`` if documentation was found.
            ``data``
                Mapping of MIME type to content (e.g. ``{"text/plain": "…"}``).
            ``metadata``
                Always an empty dict.

        Examples
        --------
        >>> kernel = PyodideKernel()
        >>> result = kernel.inspect("len", cursor_pos=3)
        >>> result["status"]
        'ok'
        >>> result["found"]
        True
        >>> "text/plain" in result["data"]
        True
        """
        import inspect as _inspect
        import pydoc

        # Find the identifier (word) at cursor position.
        source = code[:cursor_pos]
        word_start = (
            max(
                (source.rfind(ch) for ch in _WORD_DELIMITERS),
                default=-1,
            )
            + 1
        )
        name = source[word_start:].strip()

        if not name:
            return {"status": "ok", "found": False, "data": {}, "metadata": {}}

        # Resolve the name by walking dotted attribute chains so that
        # we avoid calling eval() on arbitrary user-provided expressions.
        # Reject names with consecutive dots (e.g. "foo..bar") or empty parts.
        parts = name.split(".")
        if not all(part and part.isidentifier() for part in parts):
            return {"status": "ok", "found": False, "data": {}, "metadata": {}}

        try:
            obj = self._console.globals[parts[0]]
            for attr in parts[1:]:
                obj = getattr(obj, attr)
        except (KeyError, AttributeError):
            # Fall back to builtins for names like "len", "str", …
            import builtins

            try:
                obj = getattr(builtins, parts[0])
                for attr in parts[1:]:
                    obj = getattr(obj, attr)
            except AttributeError:
                return {"status": "ok", "found": False, "data": {}, "metadata": {}}

        # Render documentation.  Use more verbose output at detail_level >= 1.
        try:
            if detail_level >= 1:
                doc = pydoc.render_doc(obj, renderer=pydoc.text)
            else:
                doc = pydoc.render_doc(obj, renderer=pydoc.plaintext)
        except Exception:
            doc = _inspect.getdoc(obj) or ""

        if not doc:
            return {"status": "ok", "found": False, "data": {}, "metadata": {}}

        return {
            "status": "ok",
            "found": True,
            "data": {"text/plain": doc},
            "metadata": {},
        }

    def is_complete(self, code: str) -> dict[str, Any]:
        """Check whether *code* is syntactically complete.

        Parameters
        ----------
        code :
            The code string to check.

        Returns
        -------
        dict
            ``status``
                ``"complete"`` — code is ready to execute.
                ``"incomplete"`` — more input is needed (e.g. open block).
                ``"invalid"`` — code contains a syntax error.
            ``indent``
                Suggested indentation string for the next line (only present
                when ``status == "incomplete"``).

        Examples
        --------
        >>> kernel = PyodideKernel()
        >>> kernel.is_complete("1 + 1")["status"]
        'complete'
        >>> kernel.is_complete("def f():")["status"]
        'incomplete'
        >>> kernel.is_complete("def f():")["indent"]
        '    '
        >>> kernel.is_complete("def f(:")["status"]
        'invalid'
        """
        from codeop import compile_command

        try:
            result = compile_command(code)
        except SyntaxError:
            return {"status": "invalid"}

        if result is None:
            # Determine suggested indentation for the continuation line.
            lines = code.splitlines()
            indent = 0
            for line in reversed(lines):
                stripped = line.rstrip()
                if stripped:
                    indent = len(line) - len(line.lstrip())
                    if stripped.endswith(":"):
                        indent += 4
                    break
            return {"status": "incomplete", "indent": " " * indent}

        return {"status": "complete"}

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def execution_count(self) -> int:
        """The current execution count."""
        return self._execution_count

    @property
    def globals(self) -> dict[str, Any]:
        """The global namespace used for code execution."""
        return self._console.globals
