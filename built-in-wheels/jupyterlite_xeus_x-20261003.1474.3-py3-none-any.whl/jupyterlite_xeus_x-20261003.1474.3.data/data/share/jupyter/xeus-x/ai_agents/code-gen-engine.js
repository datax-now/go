/**
 * Code Generation Engine
 *
 * Standalone generation functions extracted from CodeCommandExecutor.
 * Each function receives an ICodeCommandContext to access shared helpers.
 */
import { genCode, Purpose, ScriptType } from './ai_agents.js';
import { GenerationReplay, normalizePrompt, replayDisplayData, } from './cache-utils.js';
import { DisplayAdapter } from './display-adapter.js';
import { emitGeneratedDisplay } from './output-publisher.js';
export { emitGeneratedDisplay } from './output-publisher.js';
import { retryUntil } from './retry.js';
import { makeErrorResult, makeOkResult } from './result-factory.js';
import { CONSTANTS, collectModulesFromContext, deFencedCode, detectLanguage, extractFencedBlocks, } from './utilities.js';
import { validatePackageConstraints, buildConstraintViolationFeedback, buildPackageConstraintsSection, } from './package-validator.js';
import { createLogger } from './logger.js';
const { debug: _debug, info: _info, diagnostic: _diag } = createLogger('[AI_Agents]');
/**
 * Recursively clone a value with bounded depth/width, replacing circular
 * references and anything past the limits with a placeholder. Used to build
 * safe debug previews of live language-namespace snapshots (e.g. R context
 * fetched via Module.getNamespace('r')), which can be deep enough that a
 * direct JSON.stringify() overflows the JS call stack (RangeError: Maximum
 * call stack size exceeded).
 */
function boundedClone(value, depth, seen) {
    if (value === null || typeof value !== 'object') {
        return value;
    }
    if (seen.has(value)) {
        return '[Circular]';
    }
    if (depth <= 0) {
        return Array.isArray(value) ? '[Array]' : '[Object]';
    }
    seen.add(value);
    if (Array.isArray(value)) {
        return value.slice(0, 20).map((item) => boundedClone(item, depth - 1, seen));
    }
    const result = {};
    for (const key of Object.keys(value).slice(0, 50)) {
        try {
            result[key] = boundedClone(value[key], depth - 1, seen);
        }
        catch (error) {
            result[key] = `[unreadable: ${String(error?.message || error)}]`;
        }
    }
    return result;
}
/** Safe, bounded-depth preview string for debug logging. Never throws. */
function safeContextPreview(value, maxLen = 300) {
    try {
        return JSON.stringify(boundedClone(value, 4, new WeakSet())).slice(0, maxLen);
    }
    catch (error) {
        return `[context preview unavailable: ${String(error?.message || error)}]`;
    }
}
function normalizeMixedLanguage(language) {
    const lower = language.toLowerCase();
    if (lower === 'python' || lower === 'py')
        return 'python';
    if (lower === 'javascript' || lower === 'js' || lower === 'typescript' || lower === 'ts' || lower === 'tsx')
        return 'javascript';
    if (lower === 'r' || lower === 'rlang')
        return 'r';
    return undefined;
}
function validateMixedPackageConstraints(markdown, required, prohibited) {
    const blocks = extractFencedBlocks(markdown);
    const foundRequired = new Set();
    const usedProhibited = new Set();
    for (const block of blocks) {
        const language = normalizeMixedLanguage(block.language);
        if (!language)
            continue;
        const result = validatePackageConstraints(block.code, language, [], prohibited);
        result.usedProhibited.forEach((packageName) => usedProhibited.add(packageName));
        // The validator's public result intentionally exposes only violations, so
        // check required packages one at a time to determine which block provides them.
        for (const packageName of required) {
            if (validatePackageConstraints(block.code, language, [packageName], []).valid) {
                foundRequired.add(packageName.toLowerCase());
            }
        }
    }
    const missingRequired = required.filter((packageName) => !foundRequired.has(packageName.toLowerCase()));
    return {
        valid: missingRequired.length === 0 && usedProhibited.size === 0,
        missingRequired,
        usedProhibited: [...usedProhibited],
    };
}
async function runGenerationAttempts(ctx, options) {
    const { command, sourceTag, requirement, scriptType, generatingMessage, generatedMessage, emptyErrorMessage, purpose, maxTries, metadata, packageConstraints, model, mode, } = options;
    const required = (packageConstraints?.required ?? []).filter(Boolean);
    const optional = (packageConstraints?.optional ?? []).filter(Boolean);
    const prohibited = (packageConstraints?.prohibited ?? []).filter(Boolean);
    const constraintSection = buildPackageConstraintsSection(required, optional, prohibited);
    const baseRequirement = constraintSection ? `${requirement}\n\n${constraintSection}` : requirement;
    let attemptRequirement = baseRequirement;
    const { result } = await retryUntil(maxTries, async (attempt) => {
        let currentContext;
        let modules;
        let sessionId;
        if (mode.kind === 'mixed') {
            ({ currentContext, modules, sessionId } = mode);
        }
        else {
            const languageKey = mode.languageKey;
            const languageProxy = ctx.resolveLanguageProxy(languageKey);
            if (!languageProxy) {
                return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', `Unsupported language: ${languageKey}`, [`${command} does not support language: ${languageKey}`]);
            }
            try {
                const markdownContext = languageProxy.context;
                if (markdownContext && typeof markdownContext === 'string') {
                    currentContext = markdownContext;
                    _debug(`code generation context fetch (Markdown): languageKey=${languageKey}, length=${markdownContext.length}`);
                    modules = languageKey === 'python'
                        ? collectModulesFromContext(languageKey, languageProxy.vars || {})
                        : [];
                }
                else {
                    currentContext = languageProxy.vars || {};
                    _debug(`code generation context fetch (JSON): languageKey=${languageKey}, vars keys=[${Object.keys(currentContext).join(', ')}], vars=${safeContextPreview(currentContext)}`);
                    modules = collectModulesFromContext(languageKey, currentContext);
                }
            }
            catch (error) {
                return makeErrorResult(ctx.config.getExecutionCount, 'ContextError', `Failed to get execution context: ${error.message}`, [String(error.stack || error)]);
            }
            sessionId = ctx.createSessionId(command);
        }
        if (Purpose.AutoSuggest !== purpose) {
            DisplayAdapter.markdown(CONSTANTS.THINKING_MESSAGE + ' (Try ' + String(attempt) + ')', { display_id: sessionId, update: attempt !== 1 });
        }
        try {
            const generatedCode = await genCode({
                currentPrompt: attemptRequirement,
                realCode: false,
                currentContext,
                modules,
                scriptType,
                sessionId,
                summary_going: generatingMessage,
                summary_done: generatedMessage,
                finalClosed: true,
                purpose,
                metadata,
                model,
            });
            if (!generatedCode || generatedCode.trim().length === 0) {
                return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', emptyErrorMessage, ['AI returned empty code']);
            }
            const cleanCode = mode.kind === 'single'
                ? deFencedCode(generatedCode, mode.language)
                : generatedCode;
            if (required.length > 0 || prohibited.length > 0) {
                const validation = mode.kind === 'single'
                    ? validatePackageConstraints(cleanCode, mode.languageKey, required, prohibited)
                    : validateMixedPackageConstraints(cleanCode, required, prohibited);
                if (!validation.valid) {
                    const feedback = buildConstraintViolationFeedback(validation);
                    attemptRequirement = `${baseRequirement}\n\nPrevious attempt failed package constraints:\n${feedback}`;
                    _info(`${mode.kind === 'mixed' ? 'mixed ' : ''}package constraint violation on attempt ${attempt}: ${feedback}`);
                    return makeErrorResult(ctx.config.getExecutionCount, 'PackageConstraintViolation', feedback, [feedback]);
                }
            }
            const displayRecord = emitGeneratedDisplay({
                sourceTag,
                requirement,
                generated: cleanCode,
                ...(mode.kind === 'single'
                    ? { language: mode.language, detectedLanguage: mode.detectedLanguage }
                    : { isMarkdown: true }),
                displayId: sessionId,
                summary: generatedMessage,
            });
            if (mode.kind === 'single') {
                mode.replay.store(cleanCode, displayRecord ? [displayRecord] : []);
                _diag('[diag][executeGenCodeGen] stored runtime cache entry', {
                    sourceTag,
                    cellId: typeof metadata.cellId === 'string' ? metadata.cellId : '',
                    detectedLanguage: mode.detectedLanguage,
                    hasDisplayRecord: !!displayRecord,
                });
            }
            return makeOkResult(ctx.config.getExecutionCount, undefined, {
                generated: cleanCode,
                ...(mode.kind === 'single' ? { detectedLanguage: mode.detectedLanguage } : {}),
            });
        }
        catch (error) {
            if (error?.name === 'AbortError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'AbortError', 'AI code generation was stopped by user.', []);
            }
            if (error?.name === 'ProviderConfigurationError') {
                return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', error.message, [String(error.stack || error)]);
            }
            return makeErrorResult(ctx.config.getExecutionCount, 'GenerationError', `Failed to generate code: ${error.message}`, [String(error.stack || error)]);
        }
    }, (value) => value?.status === 'ok' || value?.ename === 'AbortError' ||
        value?.ename === 'ConfigurationError' || (mode.kind === 'single' && value?.ename === 'ContextError'));
    return result || makeErrorResult(ctx.config.getExecutionCount, 'MaxRetriesExceeded', `Failed after ${maxTries} attempts`);
}
/**
 * Core code generation with retry logic for a single language.
 */
export async function executeGenCodeGen(ctx, command, requirement, scriptType, language, languageKey, generatingMessage, generatedMessage, emptyErrorMessage, purpose = Purpose.FirstGen, maxTries = 5, detectedLanguage, metadata = {}, packageConstraints, model) {
    // Validate requirement
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', `Empty ${language} generation request`, [`No requirement provided after ${command}`]);
    }
    // Validate datax configuration
    if (!ctx.config.datax) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', 'datax not configured', [`${command} requires datax to be configured`]);
    }
    const resolvedMetadata = ctx.resolveMetadata(metadata);
    const lastExecuteIO = resolvedMetadata.lastExecuteIO;
    const replayAllowed = resolvedMetadata.aiCacheReplayAllowed;
    const effectiveDetectedLanguage = detectedLanguage ?? languageKey;
    const cellId = typeof resolvedMetadata.cellId === 'string'
        ? resolvedMetadata.cellId
        : undefined;
    const sourceTag = ctx.resolveSourceTag(command);
    _diag('[diag][executeGenCodeGen] resolved metadata', {
        command,
        sourceTag,
        cellId: cellId ?? '',
        replayAllowed: replayAllowed ?? 'unset',
        hasLastExecuteIO: !!lastExecuteIO,
        detectedLanguage: effectiveDetectedLanguage,
        normalizedRequirement: normalizePrompt(requirement),
    });
    const replay = new GenerationReplay({
        cellId,
        requestType: sourceTag,
        requirement,
        lastExecuteIO,
        detectedLanguage: effectiveDetectedLanguage,
        replayAllowed,
        packageConstraints,
    });
    const cacheHit = replay.lookup();
    if (cacheHit) {
        _diag('[diag][executeGenCodeGen] checkGenCache hit', {
            sourceTag,
            cellId: cellId ?? '',
            detectedLanguage: effectiveDetectedLanguage,
            displayCount: cacheHit.displayData.length,
        });
        _info(`[cache] hit for ${sourceTag} (${normalizePrompt(requirement)})`);
        replayDisplayData(cacheHit.displayData);
        return makeOkResult(ctx.config.getExecutionCount, undefined, {
            generated: cacheHit.generated,
            cached: true,
            detectedLanguage: effectiveDetectedLanguage,
        });
    }
    if (lastExecuteIO && replayAllowed !== false) {
        _diag('[diag][executeGenCodeGen] cache miss after checkGen/runtime lookup', {
            sourceTag,
            cellId: cellId ?? '',
            detectedLanguage: effectiveDetectedLanguage,
            normalizedRequirement: normalizePrompt(requirement),
        });
        _info(`[cache] miss for ${sourceTag} (${normalizePrompt(requirement)})`);
    }
    else {
        _diag('[diag][executeGenCodeGen] cache skipped before generation', {
            sourceTag,
            cellId: cellId ?? '',
            replayAllowed: replayAllowed ?? 'unset',
            hasLastExecuteIO: !!lastExecuteIO,
        });
        _info(`[cache] skip for ${sourceTag} (missing lastExecuteIO)`);
    }
    return runGenerationAttempts(ctx, {
        command, sourceTag, requirement, scriptType, generatingMessage,
        generatedMessage, emptyErrorMessage, purpose, maxTries,
        metadata: resolvedMetadata, packageConstraints, model,
        mode: { kind: 'single', language, languageKey, detectedLanguage: effectiveDetectedLanguage, replay },
    });
}
/**
 * Auto-detect language and generate code in a single detected language.
 */
export async function executeSingleLangGen(ctx, languageConfig, requirement, maxTries = 5, metadata = {}, packageConstraints, model) {
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', 'Empty code generation request', ['No requirement provided after @gen']);
    }
    const detectedLang = detectLanguage(requirement);
    // Generate code in the detected language only
    const cfg = languageConfig[detectedLang];
    return executeGenCodeGen(ctx, '@gen', requirement, cfg.scriptType, cfg.languageType, cfg.languageKey, cfg.generatingMessage, cfg.generatedMessage, cfg.emptyErrorMessage, Purpose.FirstGen, maxTries, detectedLang, metadata, packageConstraints, model);
}
/**
 * Generate code in mixed-language mode (Python + R + JS fenced blocks).
 */
export async function executeMixedGen(ctx, requirement, maxTries = 5, metadata = {}, packageConstraints, model, command = '@wildgen') {
    if (!requirement) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ExecutionError', 'Empty mixed-language generation request', ['No requirement provided after @gen']);
    }
    if (!ctx.config.datax || !ctx.config.datax.python) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ConfigurationError', 'Python language proxy required for @gen command', ['@gen command requires datax.python to be configured']);
    }
    const languageProxy = ctx.config.datax.python;
    let currentContext = {};
    let modules = [];
    try {
        const markdownContext = languageProxy.context;
        if (markdownContext && typeof markdownContext === 'string') {
            currentContext = markdownContext;
            _debug(`gen context fetch (Markdown): languageKey=python, length=${markdownContext.length}`);
            modules = collectModulesFromContext('python', languageProxy.vars || {});
        }
        else {
            currentContext = languageProxy.vars || {};
            _debug(`gen context fetch (JSON): languageKey=python, vars keys=[${Object.keys(currentContext).join(', ')}], vars=${safeContextPreview(currentContext)}`);
            modules = collectModulesFromContext('python', currentContext);
        }
    }
    catch (error) {
        return makeErrorResult(ctx.config.getExecutionCount, 'ContextError', `Failed to get execution context: ${error.message}`, [String(error.stack || error)]);
    }
    const resolvedMetadata = ctx.resolveMetadata(metadata);
    const lastExecuteIO = resolvedMetadata.lastExecuteIO;
    const replayAllowed = resolvedMetadata.aiCacheReplayAllowed;
    const sourceTag = ctx.resolveSourceTag(command);
    const replay = new GenerationReplay({
        requestType: sourceTag,
        requirement,
        lastExecuteIO,
        replayAllowed,
        packageConstraints,
    });
    const cacheHit = replay.lookup({ runtime: false });
    if (cacheHit) {
        replayDisplayData(cacheHit.displayData);
        return makeOkResult(ctx.config.getExecutionCount, undefined, {
            generated: cacheHit.generated,
            cached: true,
        });
    }
    const sessionId = ctx.createSessionId(command);
    return runGenerationAttempts(ctx, {
        command, sourceTag, requirement, scriptType: ScriptType.PyRJS,
        generatingMessage: CONSTANTS.GENERATING_MIXED_CODE,
        generatedMessage: CONSTANTS.GENERATED_MIXED_CODE,
        emptyErrorMessage: CONSTANTS.AI_MIXED_CODE_GENERATION_EMPTY_RESULT,
        purpose: Purpose.FirstGen, maxTries, metadata: resolvedMetadata,
        packageConstraints, model,
        mode: { kind: 'mixed', currentContext, modules, sessionId },
    });
}
//# sourceMappingURL=code-gen-engine.js.map