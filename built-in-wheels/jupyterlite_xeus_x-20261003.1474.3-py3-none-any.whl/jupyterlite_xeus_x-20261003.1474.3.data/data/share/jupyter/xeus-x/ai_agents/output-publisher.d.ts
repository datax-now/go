import type { JSONObject } from '@lumino/coreutils';
import type { IJupyterOutput, IRunResult } from './code-commands-types.js';
import { type AIAgentsRequestType, type CachedDisplayData } from './cache-utils.js';
/**
 * Normalize a raw output object (which may arrive as a JSON string, or
 * wrapped in an extra `data` envelope) into a standard IJupyterOutput shape.
 *
 * Returns `null` when the value cannot be recognized.
 */
export declare function normalizeRunOutput(output: unknown): IJupyterOutput | null;
/**
 * Normalize a traceback value (array or string) into a single `\n`-joined string.
 */
export declare function normalizeTraceback(traceback: string | string[] | null | undefined): string;
export declare function emitGeneratedDisplay(options: {
    sourceTag: AIAgentsRequestType;
    requirement: string;
    generated: string;
    language?: string;
    detectedLanguage?: 'python' | 'javascript' | 'r';
    isMarkdown?: boolean;
    displayId?: string;
    summary?: string;
}): CachedDisplayData | null;
export declare function buildGeneratedCodeDisplayOutput(command: string, requirement: string, generated: string, languageKey: 'python' | 'javascript' | 'r'): IJupyterOutput;
type PublicationOptions = {
    generated: string;
    detectedLanguage?: 'python' | 'javascript' | 'r';
    metadata?: JSONObject;
};
export declare class OutputPublication {
    readonly displayId: string;
    constructor(command: string);
    close(): void;
    prepare(runResult: IRunResult): {
        outputs: IJupyterOutput[];
        publish: (options: PublicationOptions) => boolean;
    };
}
export {};
//# sourceMappingURL=output-publisher.d.ts.map