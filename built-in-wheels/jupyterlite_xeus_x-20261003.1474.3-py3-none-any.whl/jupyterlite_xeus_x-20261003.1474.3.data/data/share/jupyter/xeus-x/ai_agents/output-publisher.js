import { normalizePrompt } from './cache-utils.js';
import { DisplayAdapter } from './display-adapter.js';
import { wrapCodeForDisplay } from './output-processor.js';
import { createLogger } from './logger.js';
const { info: _info } = createLogger('[AI_Agents]');
// ---------------------------------------------------------------------------
// Normalization
// ---------------------------------------------------------------------------
/**
 * Normalize a raw output object (which may arrive as a JSON string, or
 * wrapped in an extra `data` envelope) into a standard IJupyterOutput shape.
 *
 * Returns `null` when the value cannot be recognized.
 */
export function normalizeRunOutput(output) {
    if (!output)
        return null;
    let item = output;
    if (typeof item === 'string') {
        try {
            item = JSON.parse(item);
        }
        catch {
            return null;
        }
    }
    if (item && typeof item === 'object') {
        // Unwrap { data: "<json>" } envelope
        if (typeof item.data === 'string') {
            try {
                const parsed = JSON.parse(item.data);
                if (parsed && typeof parsed === 'object' && parsed.output_type) {
                    return parsed;
                }
            }
            catch {
                // fall through
            }
        }
        // Unwrap { data: { output_type: ... } } envelope
        if (item.data && typeof item.data === 'object' && item.data.output_type) {
            return item.data;
        }
        // Already a Jupyter output
        if (item.output_type) {
            return item;
        }
    }
    return null;
}
// ---------------------------------------------------------------------------
// Publishing helpers
// ---------------------------------------------------------------------------
/**
 * Normalize a traceback value (array or string) into a single `\n`-joined string.
 */
export function normalizeTraceback(traceback) {
    if (Array.isArray(traceback)) {
        return traceback.map((line) => String(line ?? '')).join('\n');
    }
    if (traceback == null)
        return '';
    return String(traceback);
}
function generatedCodeMarkdown(generated, language, summary, isMarkdown = false) {
    const content = isMarkdown ? generated : wrapCodeForDisplay(generated, language);
    return `<details ><summary>${summary}</summary><br>\n\n${content}\n</details>`;
}
export function emitGeneratedDisplay(options) {
    if (!options.generated || options.generated.trim().length === 0)
        return null;
    const createsWidget = /\bdatax\.(?:widget|widgets\.anywidget)\s*\(/.test(options.generated);
    const displaysWidget = /\bdisplay_widget\s*\(|\bdatax\.display\.display_anywidget\s*\(/.test(options.generated);
    if (createsWidget && displaysWidget)
        return null;
    const metadata = { source: options.sourceTag, prompt: normalizePrompt(options.requirement) };
    if (options.detectedLanguage)
        metadata.detectedLanguage = options.detectedLanguage;
    const markdown = generatedCodeMarkdown(options.generated, options.language ?? '', options.summary || 'Generated code', options.isMarkdown);
    const globalObject = globalThis;
    const displayData = globalObject?.datax?.display?.display_data ?? globalObject?.display_data;
    const updateDisplayData = globalObject?.datax?.display?.update_display_data ?? globalObject?.update_display_data;
    const displayId = options.displayId ? String(options.displayId) : '';
    const record = {
        output_type: displayId && typeof updateDisplayData === 'function' ? 'update_display_data' : 'display_data',
        data: { 'text/markdown': markdown },
        metadata,
        transient: displayId ? { display_id: displayId } : {},
    };
    if (record.output_type === 'update_display_data') {
        updateDisplayData(record.data, metadata, record.transient);
    }
    else if (typeof displayData === 'function') {
        displayData(record.data, metadata, record.transient);
    }
    else {
        DisplayAdapter.markdown(markdown, { metadata });
    }
    return record;
}
function summaryForCommand(command) {
    switch (command) {
        case '@pygo': return 'Generated Python code';
        case '@jsgo': return 'Generated JavaScript code';
        case '@tsgo': return 'Generated TypeScript code';
        case '@rgo': return 'Generated R code';
        case '@wildgo': return 'Generated mixed-language code';
        default: return 'Generated code';
    }
}
export function buildGeneratedCodeDisplayOutput(command, requirement, generated, languageKey) {
    return {
        output_type: 'display_data',
        data: { 'text/markdown': generatedCodeMarkdown(generated, languageKey, summaryForCommand(command)) },
        metadata: { source: String(command || '').replace(/^@/, ''), prompt: requirement },
    };
}
function getInterpreter() {
    const globalObject = globalThis;
    const moduleRef = globalObject?._dataxnow_?._xeus_module ?? globalObject?.Module;
    const direct = moduleRef?.js_interpreter ?? moduleRef?.xkernel ?? moduleRef?.interpreter;
    if (direct)
        return direct;
    if (typeof moduleRef?._get_interpreter === 'function') {
        try {
            return moduleRef._get_interpreter();
        }
        catch (error) {
            _info(`go-execution: Module._get_interpreter() failed: ${String(error?.message || error)}`);
        }
    }
    if (typeof globalObject?._get_interpreter === 'function') {
        try {
            return globalObject._get_interpreter();
        }
        catch (error) {
            _info(`go-execution: globalThis._get_interpreter() failed: ${String(error?.message || error)}`);
        }
    }
    return null;
}
function publishStreamFallbackDisplay(name, text) {
    const globalObject = globalThis;
    const displayData = globalObject?.datax?.display?.display_data ?? globalObject?.display_data;
    if (typeof displayData !== 'function')
        return false;
    displayData({ 'text/plain': name === 'stderr' ? `[stderr]\n${text}` : text }, { source: 'ai_agents_stream_fallback', stream_name: name }, {});
    return true;
}
function publishRunOutput(output, executionCount) {
    const globalObject = globalThis;
    const dxDisplay = globalObject?.datax?.display ?? null;
    const interpreter = getInterpreter();
    const moduleRef = globalObject?._dataxnow_?._xeus_module ?? globalObject?.Module;
    switch (output.output_type) {
        case 'stream': {
            const text = Array.isArray(output.text) ? output.text.join('') : output.text;
            const streamName = output.name || 'stdout';
            if (text && typeof interpreter?.publish_stream === 'function') {
                interpreter.publish_stream(streamName, text);
            }
            else if (text && publishStreamFallbackDisplay(streamName, text)) {
                _info(`go-execution: publish_stream unavailable; rendered ${streamName} via display_data fallback`);
            }
            else if (text) {
                _info(`go-execution: dropped ${streamName} because no publish_stream/display_data route was available`);
            }
            break;
        }
        case 'display_data': {
            const displayData = dxDisplay?.display_data ?? globalObject?.display_data ?? interpreter?.display_data;
            if (typeof displayData === 'function')
                displayData(output.data || {}, output.metadata || {}, output.transient || {});
            break;
        }
        case 'update_display_data': {
            const updateDisplayData = dxDisplay?.update_display_data ?? globalObject?.update_display_data ?? interpreter?.update_display_data;
            if (typeof updateDisplayData === 'function')
                updateDisplayData(output.data || {}, output.metadata || {}, output.transient || {});
            break;
        }
        case 'execute_result': {
            if (typeof moduleRef?._js_publish_execution_result === 'function') {
                moduleRef._js_publish_execution_result(executionCount ?? output.execution_count ?? 0, JSON.stringify(output.data || {}), JSON.stringify(output.metadata || {}));
            }
            else if (typeof interpreter?.publish_execution_result === 'function') {
                interpreter.publish_execution_result(executionCount ?? output.execution_count ?? 0, output.data || {}, output.metadata || {});
            }
            else {
                const displayData = dxDisplay?.display_data ?? globalObject?.display_data;
                if (typeof displayData === 'function')
                    displayData(output.data || {}, output.metadata || {}, {});
            }
            break;
        }
        case 'error': {
            const traceback = Array.isArray(output.traceback) ? output.traceback : output.traceback == null ? [] : [String(output.traceback)];
            if (typeof moduleRef?._js_publish_execution_error === 'function') {
                moduleRef._js_publish_execution_error(String(output.ename || 'ExecutionError'), String(output.evalue || ''), JSON.stringify(traceback));
            }
            else if (typeof interpreter?.publish_execution_error === 'function') {
                interpreter.publish_execution_error(output.ename || 'ExecutionError', output.evalue || '', traceback.join('\n'));
            }
            break;
        }
    }
}
function remapRedirectedDisplayOutputs(outputs, displayId) {
    let primaryDisplayId = '';
    for (const candidate of outputs) {
        if (!candidate || typeof candidate !== 'object')
            continue;
        if (candidate.output_type !== 'display_data' && candidate.output_type !== 'update_display_data')
            continue;
        const candidateDisplayId = typeof candidate.transient?.display_id === 'string' ? candidate.transient.display_id : '';
        if (candidateDisplayId) {
            primaryDisplayId = candidateDisplayId;
            break;
        }
    }
    const seenDisplayIds = Object.create(null);
    let primaryChainStarted = false;
    const remapped = [];
    for (const output of outputs) {
        if (!output || typeof output !== 'object') {
            remapped.push(output);
            continue;
        }
        if (output.output_type !== 'display_data' && output.output_type !== 'update_display_data' && output.output_type !== 'execute_result') {
            remapped.push(output);
            continue;
        }
        const transient = output.output_type === 'execute_result' ? {} : (output.transient && typeof output.transient === 'object' ? output.transient : {});
        const originalDisplayId = typeof transient.display_id === 'string' ? transient.display_id : '';
        if (originalDisplayId && originalDisplayId === primaryDisplayId) {
            primaryChainStarted = true;
            seenDisplayIds[originalDisplayId] = true;
            remapped.push({ ...output, output_type: 'update_display_data', transient: { ...transient, display_id: displayId } });
            continue;
        }
        if (!originalDisplayId) {
            if (!primaryDisplayId || !primaryChainStarted) {
                remapped.push({ ...output, output_type: 'update_display_data', transient: { ...transient, display_id: displayId } });
            }
            else {
                remapped.push(output);
            }
            continue;
        }
        const firstSeenDisplayId = !seenDisplayIds[originalDisplayId];
        seenDisplayIds[originalDisplayId] = true;
        remapped.push(output.output_type === 'update_display_data' && firstSeenDisplayId
            ? { ...output, output_type: 'display_data', transient: { ...transient } }
            : output);
    }
    return remapped;
}
function toDisplayDataPayload(value) {
    if (value == null)
        return { 'text/plain': '' };
    if (typeof value === 'string')
        return { 'text/plain': value };
    if (typeof value === 'number' || typeof value === 'boolean')
        return { 'text/plain': String(value) };
    if (typeof value === 'object') {
        try {
            return { 'application/json': value, 'text/plain': JSON.stringify(value, null, 2) };
        }
        catch {
            return { 'text/plain': String(value) };
        }
    }
    return { 'text/plain': String(value) };
}
function synthesizeRunOutputs(runResult) {
    const normalized = Array.isArray(runResult.outputs)
        ? runResult.outputs.map((item) => normalizeRunOutput(item)).filter((item) => item !== null)
        : [];
    if (normalized.length > 0)
        return normalized;
    const synthesized = [];
    if (Array.isArray(runResult.display_outputs)) {
        for (const display of runResult.display_outputs) {
            if (display && typeof display === 'object' && display.data && typeof display.data === 'object') {
                synthesized.push({ output_type: 'display_data', data: display.data, metadata: display.metadata || {}, transient: display.transient || {} });
            }
        }
    }
    if (typeof runResult.stdout === 'string' && runResult.stdout.length > 0)
        synthesized.push({ output_type: 'stream', name: 'stdout', text: runResult.stdout });
    if (typeof runResult.stderr === 'string' && runResult.stderr.length > 0)
        synthesized.push({ output_type: 'stream', name: 'stderr', text: runResult.stderr });
    if (synthesized.length === 0 && runResult.result !== undefined && runResult.result !== null) {
        synthesized.push({ output_type: 'execute_result', execution_count: runResult.execution_count ?? null, data: toDisplayDataPayload(runResult.result), metadata: {} });
    }
    if (synthesized.length === 0 && runResult.error_name) {
        synthesized.push({ output_type: 'error', ename: runResult.error_name || 'ExecutionError', evalue: runResult.error_value || '', traceback: Array.isArray(runResult.traceback) ? runResult.traceback : [] });
    }
    return synthesized;
}
export class OutputPublication {
    constructor(command) {
        this.displayId = `exec_${command.replace(/^@/, '')}_${crypto.randomUUID().replace(/-/g, '_')}`;
        const globalObject = globalThis;
        const displayData = globalObject?.datax?.display?.display_data ?? globalObject?.display_data;
        if (typeof displayData === 'function')
            displayData({ 'text/plain': '\u23f3 Running...' }, {}, { display_id: this.displayId });
    }
    close() {
        const globalObject = globalThis;
        const updateDisplayData = globalObject?.datax?.display?.update_display_data ?? globalObject?.update_display_data;
        if (typeof updateDisplayData === 'function')
            updateDisplayData({ 'text/html': '<div style="display:none;"></div>' }, {}, { display_id: this.displayId });
    }
    prepare(runResult) {
        const runtimeOutputs = synthesizeRunOutputs(runResult);
        const outputs = remapRedirectedDisplayOutputs(runtimeOutputs, this.displayId);
        return {
            outputs,
            publish: (options) => {
                const runtimeAlreadyPublished = runResult.outputs_published === true;
                const redirected = runtimeOutputs.some((output) => ((output.output_type === 'display_data' || output.output_type === 'update_display_data')
                    && typeof output.transient?.display_id === 'string'
                    && output.transient.display_id === this.displayId));
                const outputsToRepublish = redirected ? outputs.filter((output) => output.output_type !== 'stream') : outputs;
                const republishOutputs = !runtimeAlreadyPublished && outputsToRepublish.length > 0;
                this.close();
                if (republishOutputs) {
                    for (const output of outputsToRepublish)
                        publishRunOutput(output, runResult.execution_count);
                }
                let publishedFallback = false;
                if (!runtimeAlreadyPublished && !republishOutputs
                    && options.metadata?.systemPromptAlias !== true && options.detectedLanguage !== 'javascript'
                    && typeof options.generated === 'string' && options.generated.trim().length > 0) {
                    const widget = options.generated.includes('display_widget(')
                        || options.generated.includes('datax.widget(')
                        || options.generated.includes('datax.widgets.anywidget(');
                    if (!widget) {
                        publishRunOutput({ output_type: 'display_data', data: { 'text/plain': options.generated }, metadata: {}, transient: { display_id: '__xeus_ai_cmd_display' } });
                        publishedFallback = true;
                    }
                }
                return runtimeAlreadyPublished || republishOutputs || publishedFallback;
            },
        };
    }
}
//# sourceMappingURL=output-publisher.js.map