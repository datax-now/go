export declare const DEFAULT_MODEL = "gpt-5-mini";
export type JupyterAIProviderConfig = {
    id: string;
    provider: string;
    model: string;
    name: string;
    apiKey?: string;
    baseURL?: string;
    headers?: Record<string, string>;
    parameters?: {
        temperature?: number;
        maxOutputTokens?: number;
    };
};
export declare function getActiveProviderConfig(): JupyterAIProviderConfig | null;
//# sourceMappingURL=provider-config.d.ts.map