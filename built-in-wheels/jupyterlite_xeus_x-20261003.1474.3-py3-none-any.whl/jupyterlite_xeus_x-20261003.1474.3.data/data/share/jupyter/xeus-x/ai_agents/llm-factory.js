import { LLMRegistry, model as resolveRegisteredModel, registerFromJupyterAI, } from './llm-registry.js';
import { createOpenAICompatibleEmbeddingModel, createOpenAICompatibleLanguageModel, isNonEmptyString, } from './openai-compatible.js';
import { createFrontendDelegatedLanguageModel } from './frontend-delegated-model.js';
import { resolveWindow } from './utilities.js';
import { DEFAULT_MODEL, getActiveProviderConfig } from './provider-config.js';
export { getActiveProviderConfig } from './provider-config.js';
export { DUMMY_API_KEY, createCompatibleFetch, isNonEmptyString } from './openai-compatible.js';
function getFiniteNumber(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
const TEMPERATURE_UNSUPPORTED_REASONING_MODELS = new Set([
    'gpt-5-mini',
]);
function getEffectiveModelName(config, modelOverride) {
    const trimmedOverride = typeof modelOverride === 'string' ? modelOverride.trim() : '';
    if (trimmedOverride.length === 0) {
        return typeof config?.model === 'string' ? config.model.trim().toLowerCase() : '';
    }
    const overrideModel = trimmedOverride.includes('/')
        ? trimmedOverride.slice(trimmedOverride.indexOf('/') + 1)
        : trimmedOverride;
    return overrideModel.trim().toLowerCase();
}
function sanitizeLLMRequestOptions(options, config, modelOverride) {
    const modelName = getEffectiveModelName(config, modelOverride);
    if (options.temperature !== undefined &&
        TEMPERATURE_UNSUPPORTED_REASONING_MODELS.has(modelName)) {
        const { temperature: _temperature, ...remainingOptions } = options;
        return remainingOptions;
    }
    return options;
}
/**
 * Resolve effective generation-call options from explicit per-request overrides
 * and the active provider's configured defaults.
 *
 * The AI SDK consumes these at call / agent-construction time rather than when
 * creating the provider-backed `LanguageModel` instance.
 */
export function resolveLLMRequestOptions(overrides = {}, config = getActiveProviderConfig(), modelOverride) {
    const providerTemperature = getFiniteNumber(config?.parameters?.temperature);
    const providerMaxOutputTokens = getFiniteNumber(config?.parameters?.maxOutputTokens);
    const overrideTemperature = getFiniteNumber(overrides.temperature);
    const overrideMaxOutputTokens = getFiniteNumber(overrides.maxOutputTokens);
    const resolvedOptions = {
        ...(overrideTemperature !== undefined
            ? { temperature: overrideTemperature }
            : providerTemperature !== undefined
                ? { temperature: providerTemperature }
                : {}),
        ...(overrideMaxOutputTokens !== undefined
            ? { maxOutputTokens: overrideMaxOutputTokens }
            : providerMaxOutputTokens !== undefined
                ? { maxOutputTokens: providerMaxOutputTokens }
                : {}),
    };
    return sanitizeLLMRequestOptions(resolvedOptions, config, modelOverride);
}
function registerProviderAlias(registry, config, alias) {
    registry.registerProvider(alias, {
        apiKey: config.apiKey,
        baseURL: config.baseURL,
        headers: config.headers,
        defaultModel: config.model,
    }, (_auth, modelName) => createOpenAICompatibleLanguageModel(config, modelName));
}
function createRegistryFromProvider(config) {
    const registry = new LLMRegistry();
    registerProviderAlias(registry, config, config.provider || 'default');
    registerProviderAlias(registry, config, 'default');
    return registry;
}
function resolveModelFromConfig(config, modelId) {
    const trimmedModel = typeof modelId === 'string' ? modelId.trim() : '';
    const requestedModel = trimmedModel.includes('/')
        ? trimmedModel.slice(trimmedModel.indexOf('/') + 1)
        : trimmedModel || config.model || DEFAULT_MODEL;
    if (!isNonEmptyString(config.apiKey)
        && !Object.entries(config.headers ?? {}).some(([name, value]) => name.toLowerCase() === 'authorization' && isNonEmptyString(value))) {
        return createFrontendDelegatedLanguageModel(config, requestedModel);
    }
    const registry = createRegistryFromProvider(config);
    if (trimmedModel.length > 0) {
        if (trimmedModel.includes('/')) {
            return registry.model(trimmedModel);
        }
        return registry.model(`${config.provider}/${trimmedModel}`);
    }
    return registry.model(`${config.provider}/${config.model || DEFAULT_MODEL}`);
}
// ---------------------------------------------------------------------------
// LLM creation (Vercel AI SDK)
// ---------------------------------------------------------------------------
/**
 * Create a Vercel AI SDK `LanguageModelV1` instance from a provider config.
 *
 * Models are resolved through a per-provider registry first so that
 * `provider/model` identifiers and future native-provider factories have a
 * canonical path. The OpenAI-compatible transport remains the fallback
 * implementation behind that registry entry.
 */
export function createLLMFromProvider(config, _temperatureOverride) {
    return resolveModelFromConfig(config);
}
export function createEmbeddingModelFromProvider(config) {
    return createOpenAICompatibleEmbeddingModel(config, config.model || 'text-embedding-3-small');
}
// ---------------------------------------------------------------------------
// Per-request model override
// ---------------------------------------------------------------------------
/**
 * Public default model identifier used by the DataX API when no `model`
 * option is provided by the caller.
 */
export const DEFAULT_API_MODEL = 'openai/gpt-5-mini';
/** Legacy process-level model override for compatibility with older callers. */
let _modelOverride = undefined;
/**
 * Override the model used by the next LLM call.
 * Pass `undefined` to clear the override and restore the active provider's
 * configured model.
 *
 * @deprecated Prefer passing `modelOverride` directly to {@link getLLM} to
 * avoid shared mutable request state.
 */
export function setModelOverride(model) {
    _modelOverride = model;
}
function isRegistryModelOverride(modelOverride) {
    if (typeof modelOverride !== 'string') {
        return false;
    }
    const trimmed = modelOverride.trim();
    if (trimmed.length === 0) {
        return false;
    }
    const slashIdx = trimmed.indexOf('/');
    return slashIdx > 0 && slashIdx < trimmed.length - 1;
}
// ---------------------------------------------------------------------------
// Cached LLM getter
// ---------------------------------------------------------------------------
let _cachedLLM = null;
let _cachedConfigSnapshot = null;
let _cachedEmbeddingModel = null;
let _cachedEmbeddingConfigSnapshot = null;
/**
 * Get (or create) a cached LLM instance from the active `window.jupyter_ai`
 * provider.
 *
 * The cache is invalidated when the `jupyter_ai` reference changes (the
 * global-api replaces the frozen object on every settings update).
 *
 * When `modelOverride` is supplied (preferred) or when a per-request model
 * override is active via {@link setModelOverride} (legacy, WASM-only), the
 * cache is bypassed and a fresh instance is returned using the overridden
 * model with the rest of the active provider's settings.
 *
 * Prefer passing `modelOverride` directly rather than using
 * {@link setModelOverride} — the direct parameter is safe for concurrent
 * callers, whereas the module-level override is not.
 *
 * @param temperatureOverride  Optional temperature; falls back to the
 *                             provider's configured temperature.
 * @param modelOverride        Optional model id; bypasses the cache and
 *                             overrides the provider's configured model for
 *                             this single call.
 * @returns A `LanguageModel` or `null` when no provider is configured.
 */
export function getLLM(temperatureOverride, modelOverride) {
    const config = getActiveProviderConfig();
    if (!config) {
        return null;
    }
    // Explicit per-call model override takes precedence over the legacy global.
    const effectiveModelOverride = typeof modelOverride === 'string' && modelOverride.trim().length > 0
        ? modelOverride.trim()
        : _modelOverride;
    // When any model override is active, skip the cache entirely so
    // the specified model is always used without polluting the shared cache.
    if (effectiveModelOverride !== undefined) {
        if (isRegistryModelOverride(effectiveModelOverride)) {
            registerFromJupyterAI(undefined, 'default');
            return resolveRegisteredModel(effectiveModelOverride);
        }
        return resolveModelFromConfig({ ...config, model: effectiveModelOverride }, effectiveModelOverride);
    }
    // Invalidate cache when the jupyter_ai snapshot is replaced.
    const w = resolveWindow();
    const currentSnapshot = w?.jupyter_ai;
    if (_cachedLLM && _cachedConfigSnapshot === currentSnapshot && temperatureOverride === undefined) {
        return _cachedLLM;
    }
    const llm = createLLMFromProvider(config, temperatureOverride);
    // Only cache when no temperature override (callers with overrides get fresh instances).
    if (temperatureOverride === undefined) {
        _cachedLLM = llm;
        _cachedConfigSnapshot = currentSnapshot;
    }
    return llm;
}
export function getLLMRequestOptions(overrides = {}, modelOverride) {
    return resolveLLMRequestOptions(overrides, getActiveProviderConfig(), modelOverride);
}
export function getEmbeddingModel(modelOverride) {
    const config = getActiveProviderConfig();
    if (!config) {
        return null;
    }
    const effectiveModelOverride = typeof modelOverride === 'string' && modelOverride.trim().length > 0
        ? modelOverride.trim()
        : _modelOverride;
    if (effectiveModelOverride !== undefined) {
        return createEmbeddingModelFromProvider({ ...config, model: effectiveModelOverride });
    }
    const w = resolveWindow();
    const currentSnapshot = w?.jupyter_ai;
    if (_cachedEmbeddingModel && _cachedEmbeddingConfigSnapshot === currentSnapshot) {
        return _cachedEmbeddingModel;
    }
    const embeddingModel = createEmbeddingModelFromProvider(config);
    _cachedEmbeddingModel = embeddingModel;
    _cachedEmbeddingConfigSnapshot = currentSnapshot;
    return embeddingModel;
}
//# sourceMappingURL=llm-factory.js.map