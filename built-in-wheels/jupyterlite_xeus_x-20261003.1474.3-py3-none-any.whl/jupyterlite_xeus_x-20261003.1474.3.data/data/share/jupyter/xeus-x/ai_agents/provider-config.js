import { isNonEmptyString } from './openai-compatible.js';
export const DEFAULT_MODEL = 'gpt-5-mini';
function getWindowCandidates() {
    const globalObject = globalThis;
    return [...new Set([globalObject?._window, globalObject?.window, globalObject].filter(Boolean))];
}
function describeProviderRuntime(windows) {
    const globalObject = globalThis;
    const valueType = (value) => value === null ? 'null' : value === undefined ? 'missing' : typeof value;
    return {
        windowProxyType: valueType(globalObject?._window),
        windowType: valueType(globalObject?.window),
        candidates: windows.map((windowObject, index) => {
            const jupyterAI = windowObject?.jupyter_ai;
            const settings = jupyterAI && typeof jupyterAI === 'object' ? jupyterAI.settings : undefined;
            const configuredProviders = settings?.providers;
            return {
                index,
                jupyterAIState: valueType(jupyterAI),
                settingsState: valueType(settings),
                settingsProvidersType: Array.isArray(configuredProviders) ? 'array' : valueType(configuredProviders),
                configuredProviderCount: Array.isArray(configuredProviders) ? configuredProviders.length : 0,
                hasOpenAIAPIBase: isNonEmptyString(windowObject?.OPENAI_API_BASE),
            };
        }),
    };
}
function getFirstRuntimeString(candidates, property) {
    for (const candidate of candidates) {
        if (isNonEmptyString(candidate?.[property]))
            return candidate[property].trim();
    }
    return undefined;
}
function normalizeBaseURL(value) {
    return typeof value === 'string' ? value.trim().replace(/\/+$/, '').toLowerCase() : '';
}
function getEnvFallbackProviderConfig() {
    const candidates = getWindowCandidates();
    const base = getFirstRuntimeString(candidates, 'OPENAI_API_BASE') ?? '';
    if (!base)
        return null;
    return {
        id: 'datax-fallback',
        provider: 'openai',
        model: getFirstRuntimeString(candidates, 'OPENAI_API_MODEL') ?? DEFAULT_MODEL,
        name: 'DataX Fallback',
        baseURL: base.replace(/\/+$/, ''),
        apiKey: getFirstRuntimeString(candidates, 'OPENAI_API_KEY') ?? 'datax.now',
        headers: {},
    };
}
const API_KEY_PLACEHOLDERS = new Set(['nokey', 'no-key', 'sk-no-key-required']);
function resolveProviderApiKey(providerApiKeys, windowObjects, provider, baseURL) {
    for (const providerApiKey of providerApiKeys) {
        if (isNonEmptyString(providerApiKey) && !API_KEY_PLACEHOLDERS.has(providerApiKey.trim().toLowerCase()))
            return providerApiKey.trim();
    }
    const providerBaseURL = normalizeBaseURL(baseURL);
    for (const windowObject of windowObjects) {
        const fallbackBaseURL = normalizeBaseURL(windowObject?.OPENAI_API_BASE);
        if (providerBaseURL && fallbackBaseURL === providerBaseURL && isNonEmptyString(windowObject?.OPENAI_API_KEY))
            return windowObject.OPENAI_API_KEY.trim();
    }
    if (provider === 'generic' && typeof baseURL === 'string' && /^https:\/\/dataxnow\.helloway\.workers\.dev\/v1\/?$/i.test(baseURL.trim()))
        return 'datax.now';
    return undefined;
}
export function getActiveProviderConfig() {
    const windows = getWindowCandidates();
    const jupyterAIValue = windows.map((windowObject) => windowObject?.jupyter_ai).find((value) => value !== undefined && value !== null);
    const jupyterAI = jupyterAIValue && typeof jupyterAIValue === 'object' ? jupyterAIValue : null;
    if (!jupyterAI) {
        const fallback = getEnvFallbackProviderConfig();
        if (fallback)
            return fallback;
        console.error('[getActiveProviderConfig] No usable provider configuration found.', {
            reason: jupyterAIValue !== undefined && jupyterAIValue !== null
                ? 'window.jupyter_ai is present but is not an object, and OPENAI_API_BASE is not configured.'
                : 'window.jupyter_ai is missing or null, and OPENAI_API_BASE is not configured.',
            providerRuntime: describeProviderRuntime(windows),
        });
        return null;
    }
    const configuredProviders = jupyterAI.settings?.providers;
    const providers = Array.isArray(configuredProviders) ? configuredProviders : [];
    const defaultProviderId = typeof jupyterAI.settings?.defaultProvider === 'string' ? jupyterAI.settings.defaultProvider : '';
    const active = providers.find((provider) => provider?.id === defaultProviderId)
        ?? jupyterAI.active_provider ?? jupyterAI.active_providers ?? providers[0];
    if (!active) {
        const fallback = getEnvFallbackProviderConfig();
        if (fallback)
            return fallback;
        console.error('[getActiveProviderConfig] No usable provider configuration found.', {
            reason: 'window.jupyter_ai is available, but no active or configured provider was found and OPENAI_API_BASE is not configured.',
            defaultProviderId: defaultProviderId || null,
            configuredProviderCount: providers.length,
            settingsProvidersType: configuredProviders === undefined ? 'missing' : configuredProviders === null ? 'null' : Array.isArray(configuredProviders) ? 'array' : typeof configuredProviders,
            configuredProviderIds: providers.map((provider) => provider?.id).filter((id) => typeof id === 'string'),
            hasActiveProvider: Boolean(jupyterAI.active_provider),
            hasLegacyActiveProvider: Boolean(jupyterAI.active_providers),
            providerRuntime: describeProviderRuntime(windows),
        });
        return null;
    }
    const fullConfigs = windows.flatMap((windowObject) => {
        const windowProviders = windowObject?.jupyter_ai?.settings?.providers;
        return Array.isArray(windowProviders) ? windowProviders : [];
    });
    const fullConfig = fullConfigs.find((provider) => provider?.id === active.id && isNonEmptyString(provider?.apiKey))
        ?? fullConfigs.find((provider) => provider?.id === active.id);
    return {
        id: String(active.id),
        provider: String(active.provider),
        model: String(active.model),
        name: String(active.name),
        baseURL: active.baseURL ?? fullConfig?.baseURL,
        apiKey: resolveProviderApiKey([active.apiKey, fullConfig?.apiKey], windows, active.provider, active.baseURL ?? fullConfig?.baseURL),
        headers: active.headers ?? fullConfig?.headers,
        parameters: active.parameters ?? fullConfig?.parameters,
    };
}
//# sourceMappingURL=provider-config.js.map