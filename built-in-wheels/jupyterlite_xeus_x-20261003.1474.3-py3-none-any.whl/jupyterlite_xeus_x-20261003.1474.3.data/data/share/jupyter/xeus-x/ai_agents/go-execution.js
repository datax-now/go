import { genCode as internalGenCode, Purpose, ScriptType } from './ai_agents.js';
import { recordRepairedGeneration } from './cache-utils.js';
import { createLogger } from './logger.js';
import { buildGeneratedCodeDisplayOutput, OutputPublication } from './output-publisher.js';
import { makeErrorResult, makeOkResult } from './result-factory.js';
import { collectModulesFromContext, } from './utilities.js';
const { info: _info } = createLogger('[AI_Agents]');
function quietRunOptions(language, sessionId, streamRedirectDisplayId = '') {
    const options = {
        language,
        variable_sync: 'off',
        session_id: sessionId,
        streaming: { enabled: true, display: { initial: 'invisible', end: 'invisible' } },
    };
    if (streamRedirectDisplayId) {
        options.stream_redirect_display_id = streamRedirectDisplayId;
    }
    return options;
}
function hasExplicitRunError(runResult, outputs) {
    if (runResult.error_name || runResult.error_value) {
        return true;
    }
    if (outputs.some((output) => output.output_type === 'error')) {
        return true;
    }
    return extractTracebackFromOutputs(outputs).length > 0;
}
function extractStderrTexts(outputs) {
    return outputs
        .filter((output) => output.output_type === 'stream' &&
        output.name === 'stderr' &&
        typeof output.text === 'string' &&
        output.text.length > 0)
        .map((output) => output.text);
}
function looksLikeTracebackLine(line) {
    const trimmed = line.trim();
    if (!trimmed) {
        return false;
    }
    return /traceback \(most recent call last\):/i.test(trimmed) ||
        /^[A-Za-z_][A-Za-z0-9_.]*(Error|Exception):/.test(trimmed) ||
        /^Error:/.test(trimmed);
}
function extractTracebackFromOutputs(outputs) {
    const traceback = [];
    for (const stderrText of extractStderrTexts(outputs)) {
        const lines = String(stderrText)
            .split(/\r?\n/)
            .map((line) => line.trimEnd())
            .filter((line) => line.length > 0);
        if (lines.some(looksLikeTracebackLine)) {
            traceback.push(...lines);
        }
    }
    return traceback;
}
function summarizeRuntimeError(runResult, outputs) {
    const traceback = Array.isArray(runResult.traceback) && runResult.traceback.length > 0
        ? runResult.traceback
        : extractTracebackFromOutputs(outputs);
    const fallbackErrorLine = traceback.length > 0
        ? traceback[traceback.length - 1]
        : extractStderrTexts(outputs)
            .flatMap((text) => String(text).split(/\r?\n/))
            .map((line) => line.trim())
            .filter((line) => line.length > 0)
            .pop();
    return {
        ename: runResult.error_name || 'ExecutionError',
        evalue: runResult.error_value || fallbackErrorLine || 'Code execution failed',
        traceback,
    };
}
function extractMissingModuleName(message) {
    const patterns = [
        /No module named ['"]([^'"]+)['"]/i,
        /Cannot find module ['"]([^'"]+)['"]/i,
        /there is no package called ['"]([^'"]+)['"]/i,
    ];
    for (const pattern of patterns) {
        const match = pattern.exec(message);
        if (match?.[1]) {
            return match[1];
        }
    }
    return null;
}
function buildRepairRequirement(failure) {
    const runtimeError = summarizeRuntimeError(failure.runResult, failure.outputs);
    const messages = [
        runtimeError.evalue,
        ...runtimeError.traceback,
    ]
        .filter((value) => typeof value === 'string' && value.trim().length > 0);
    for (const message of messages) {
        const missingModule = extractMissingModuleName(message);
        if (missingModule) {
            return `${failure.requirement}\n\nRepair guidance: The previous code failed because module "${missingModule}" is unavailable in this runtime. Do not import or depend on "${missingModule}" in the fix. Use packages that are already available in the current environment or rewrite the solution without that dependency.`;
        }
    }
    return failure.requirement;
}
function hasMeaningfulRunOutputs(outputs) {
    for (const output of outputs) {
        if (output.output_type === 'error')
            continue;
        if (output.output_type === 'stream') {
            if (output.name === 'stdout' && typeof output.text === 'string' && output.text.length > 0)
                return true;
            continue;
        }
        if (output.output_type === 'display_data' ||
            output.output_type === 'update_display_data' ||
            output.output_type === 'execute_result') {
            if (output.data && typeof output.data === 'object')
                return true;
            continue;
        }
        return true;
    }
    return false;
}
function hasSuccessfulRunStatus(status) {
    if (typeof status !== 'string') {
        return false;
    }
    const normalized = status.trim().toLowerCase();
    return normalized === 'completed' || normalized === 'succeeded' || normalized === 'success' || normalized === 'ok';
}
function hasMissingRunStatus(status) {
    return typeof status !== 'string' || status.trim().length === 0;
}
function resolveMaxAttempts(metadata, fallback = 5) {
    const raw = metadata?.maxRetries ?? metadata?.max_retries;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || parsed < 1) {
        return Math.max(1, Math.floor(fallback));
    }
    return Math.max(1, Math.floor(parsed));
}
function refreshRuntimeReplayCache(options, generated) {
    const cellId = typeof options.metadata?.cellId === 'string'
        ? options.metadata.cellId
        : undefined;
    if (!cellId || !generated) {
        return;
    }
    const displayRecord = buildGeneratedCodeDisplayOutput(options.command, options.requirement, generated, options.genResult.detectedLanguage || options.languageKey);
    recordRepairedGeneration({
        cellId,
        command: options.command,
        requirement: options.requirement,
        detectedLanguage: options.genResult.detectedLanguage || options.languageKey,
        packageConstraints: options.packageConstraints,
        generated,
        displayData: [displayRecord],
    });
}
function buildLastExecuteIOForRetry(failure) {
    const runtimeError = summarizeRuntimeError(failure.runResult, failure.outputs);
    return {
        status: 'error',
        prompt: failure.requirement,
        code: failure.currentCode,
        generated_code: failure.currentCode,
        code_language: failure.languageKey,
        output_model: [
            buildGeneratedCodeDisplayOutput(failure.command, failure.requirement, failure.currentCode, failure.languageKey),
            ...failure.outputs,
        ],
        execution_result: {
            status: 'error',
            ename: runtimeError.ename,
            evalue: runtimeError.evalue,
            traceback: runtimeError.traceback,
        },
    };
}
function retryScriptType(languageKey) {
    switch (languageKey) {
        case 'python':
            return ScriptType.PyOnly;
        case 'javascript':
            return ScriptType.JsOnly;
        case 'r':
            return ScriptType.ROnly;
    }
}
function retrySummaries(command) {
    switch (command) {
        case '@pygo':
            return { going: 'Fixing Python code...', done: 'Fixed Python code' };
        case '@jsgo':
            return { going: 'Fixing JavaScript code...', done: 'Fixed JavaScript code' };
        case '@tsgo':
            return { going: 'Fixing TypeScript code...', done: 'Fixed TypeScript code' };
        case '@rgo':
            return { going: 'Fixing R code...', done: 'Fixed R code' };
        default:
            return { going: 'Fixing generated code...', done: 'Fixed generated code' };
    }
}
function getProxyContext(languageKey, proxy) {
    const markdownContext = typeof proxy.context === 'string' && proxy.context.trim().length > 0
        ? proxy.context
        : null;
    if (markdownContext) {
        const modules = languageKey === 'python'
            ? collectModulesFromContext(languageKey, proxy.vars || {})
            : [];
        return { context: markdownContext, modules };
    }
    const rawVars = proxy.vars || {};
    const modules = collectModulesFromContext(languageKey, rawVars);
    return { context: rawVars, modules };
}
export function buildRuntimeRepairCallback(options) {
    return async (failure) => {
        const retryMetadata = {
            ...(failure.metadata || {}),
            lastExecuteIO: buildLastExecuteIOForRetry(failure),
        };
        const proxyContext = getProxyContext(options.languageKey, failure.proxy);
        const summary = retrySummaries(options.command);
        try {
            return await internalGenCode({
                currentPrompt: buildRepairRequirement(failure),
                realCode: false,
                currentContext: proxyContext.context,
                modules: proxyContext.modules,
                scriptType: retryScriptType(options.languageKey),
                sessionId: `fix_${crypto.randomUUID().replace(/-/g, '_')}`,
                summary_going: summary.going,
                summary_done: summary.done,
                finalClosed: true,
                purpose: Purpose.FixRuntimeIssue,
                metadata: retryMetadata,
                showStopButton: false,
            });
        }
        catch (error) {
            _info(`runtime repair failed for ${options.command}: ${String(error?.message || error)}`);
            throw error;
        }
    };
}
export async function executeGeneratedCodeWithRetry(options) {
    if (options.genResult.status !== 'ok' || !options.genResult.generated) {
        return options.genResult;
    }
    const maxAttempts = resolveMaxAttempts(options.metadata, options.maxAttempts ?? 5);
    const sessionPrefix = options.command.replace(/^@/, '');
    let currentCode = options.genResult.generated;
    let lastError = null;
    const publication = new OutputPublication(options.command);
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        let runResult;
        try {
            runResult = await options.proxy.run(currentCode, quietRunOptions(options.languageType, `${sessionPrefix}_${attempt}`, publication.displayId));
        }
        catch (error) {
            publication.close();
            return makeErrorResult(options.getExecutionCount, 'ExecutionError', `Execution failed: ${String(error?.message || error)}`, [String(error?.stack || error)]);
        }
        const capturedOutput = publication.prepare(runResult);
        const normalizedOutputs = capturedOutput.outputs;
        const runStatus = runResult.status;
        const executionSucceeded = !hasExplicitRunError(runResult, normalizedOutputs) &&
            (hasSuccessfulRunStatus(runStatus) ||
                (hasMissingRunStatus(runStatus) && hasMeaningfulRunOutputs(normalizedOutputs)));
        if (executionSucceeded) {
            if (currentCode !== options.genResult.generated) {
                refreshRuntimeReplayCache(options, currentCode);
            }
            const detectedLanguage = options.genResult.detectedLanguage || options.languageKey;
            const outputsPublished = capturedOutput.publish({ generated: currentCode, detectedLanguage, metadata: options.metadata });
            return makeOkResult(options.getExecutionCount, runResult.execution_count, {
                user_expressions: {},
                outputs: normalizedOutputs,
                outputs_published: outputsPublished,
                generated: currentCode,
                detectedLanguage,
            });
        }
        const runtimeError = summarizeRuntimeError(runResult, normalizedOutputs);
        lastError = makeErrorResult(options.getExecutionCount, runtimeError.ename, runtimeError.evalue, runtimeError.traceback, {
            outputs: normalizedOutputs,
            generated: currentCode,
            detectedLanguage: options.genResult.detectedLanguage || options.languageKey,
        });
        if (attempt >= maxAttempts) {
            publication.close();
            return lastError;
        }
        const repairedCode = await options.repairCode({
            command: options.command,
            requirement: options.requirement,
            currentCode,
            languageKey: options.languageKey,
            languageType: options.languageType,
            proxy: options.proxy,
            metadata: options.metadata ?? {},
            runResult,
            outputs: normalizedOutputs,
        });
        const normalizedCurrentCode = currentCode.trim();
        const normalizedRepairedCode = typeof repairedCode === 'string'
            ? repairedCode.trim()
            : '';
        if (normalizedRepairedCode.length === 0) {
            _info(`runtime repair returned empty code for ${options.command}; continuing retry loop`);
            continue;
        }
        if (normalizedRepairedCode === normalizedCurrentCode) {
            _info(`runtime repair returned unchanged code for ${options.command}; continuing retry loop`);
            continue;
        }
        currentCode = repairedCode;
    }
    publication.close();
    return (lastError ||
        makeErrorResult(options.getExecutionCount, 'ExecutionError', 'Code execution failed', []));
}
//# sourceMappingURL=go-execution.js.map