"""jupyterlite-xeus-x — kernel bundle for JupyterLite."""
__version__ = '20261003.1474.3'
